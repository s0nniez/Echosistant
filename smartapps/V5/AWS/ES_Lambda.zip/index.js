/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.4.00 - 6/30/2017 Completely overhaul!
 *  Version 5.3.00 - 6/21/2017 Added US Skill
 *  Version 5.1.00 - 3/21/2017 Added Reminders Profile
 *
 *  Special thanks for Michael Struck @MichaelS (Developer of AskAlexa) for allowing me
 *  to build off of his base code.  Special thanks to Keith DeLong  @N8XD for his
 *  assistance in troubleshooting.... as I learned.....  Special thanks to Bobby
 *  @SBDOBRESCU for jumping on board and being a co-consipirator in this adventure.
 *
 *  Version 5.0.00 - 3/24/2017 Beta Release
 *  Version 4.0.00 - 2/17/2017 Public Release
 *  Version 3.0.00 - 12/1/2016  Added new parent variables
 *  Version 2.0.00 - 11/20/2016  Continued Commands
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const https = require('https');
const STtoken = process.env.STtoken;
const STurl = process.env.STurl;
const versionTxt = '5.4';

//will eventually be an env var...
var keywords = {
    'feedback': ['give', 'for', 'tell', 'what', 'how', 'is', 'when', 'which', 'are', 'how many', 'check', 'who', 'status'],
    'enable': ['on', 'start', 'enable', 'engage', 'open', 'begin', 'unlock', 'unlocked'],
    'disable': ['off', 'stop', 'cancel', 'disable', 'disengage', 'kill', 'close', 'silence', 'lock', 'locked', 'quit', 'end'],
    'more': ['increase', 'more', 'too dark', 'not bright enough', 'brighten', 'brighter', 'turn up'],
    'less': ['darker', 'too bright', 'dim', 'dimmer', 'decrease', 'lower', 'low', 'softer', 'less'],
    'delay': ['delay', 'wait', 'until', 'after', 'around', 'within', 'in', 'about']
};

//will eventually be an env var...
var deviceTypes = [
    'light', 'switch', 'fan', 'lock', 'garage', 'door', 'window', 'shade', 'curtain', 'blind', 'tstat', 'indoor', 'outdoor', 'vent', 'valve', 'water', 'speaker', 'synth', 'media', 'relay'
];

/*
for (var keyword in keywords) {
    if (keywords[keyword].find((it) => theCommand.includes(it))) {
        console.log(keyword);
    }
}
*/


const languageStrings = {
    'en-GB': {
        'translation': {
            'SKILL_NAME': 'EchoSistant',
            'WELCOME_MESSAGE': 'Yes',
            'WELCOME_REPROMT': 'Welcome reprompt',
            'REPROMPT_SPEECH': 'Anything else?',
            'EXIT_SKILL_MESSAGE': 'Goodbye',
            'HELP_MESSAGE': 'Examples of things to say',
            'HELP_REPROMT': 'Help reprompt',
            'STOP_MESSAGE': 'I am here if you need me',
            'SETTINGS_UPDATED' : 'I have updated your settings.',
            'ERROR' : 'Something went wrong'
        }
    },
    'en-US': {
        'translation': {
            'SKILL_NAME': 'EchoSistant',
            'WELCOME_MESSAGE': 'Hello',
            'WELCOME_REPROMT': 'Welcome reprompt',
            'REPROMPT_SPEECH': 'Anything else?',
            'EXIT_SKILL_MESSAGE': 'Goodbye',
            'HELP_MESSAGE': 'Examples of things to say',
            'HELP_REPROMT': 'Help reprompt',
            'STOP_MESSAGE': 'I am here if you need me',
            'SETTINGS_UPDATED' : 'I have updated your settings.',
            'ERROR' : 'Something went wrong'
        }
    },
    'de-DE': {
        'translation': {
            'SKILL_NAME': 'EchoSistant',
            'WELCOME_MESSAGE': 'Hallo',
            'WELCOME_REPROMT': 'Welcome reprompt',
            'REPROMPT_SPEECH': 'Anything else?',
            'EXIT_SKILL_MESSAGE': 'Goodbye',
            'HELP_MESSAGE': 'Examples of things to say',
            'HELP_REPROMT': 'Help reprompt',
            'STOP_MESSAGE': 'I am here if you need me',
            'SETTINGS_UPDATED' : 'I have updated your settings.',
            'ERROR' : 'Something went wrong'
        }
    }
};

const handlers = {
    /*'NewSession': function () {
        console.log('NewSession');
        if (process.env.profileData === undefined || process.env.profileData === '') {
            this.emitWithState('UpdateSettings');
        } else {
            this.attributes.speechOutput = this.t('WELCOME_MESSAGE', this.t('SKILL_NAME'));
            // If the user either does not reply to the welcome message or says something that is not
            // understood, they will be prompted again with this text.
            this.attributes.repromptSpeech = this.t('WELCOME_REPROMT');
            this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
        }
    }, */   
    'LaunchRequest': function () {
        console.log('In LaunchRequest');
        if (process.env.allESSettings === undefined || process.env.allESSettings === '' || process.env.allESSettings === 'empty') {
            this.emitWithState('UpdateSettings');
        } else {
            this.attributes.speechOutput = this.t('WELCOME_MESSAGE', this.t('SKILL_NAME'));
            // If the user either does not reply to the welcome message or says something that is not
            // understood, they will be prompted again with this text.
            this.attributes.repromptSpeech = this.t('WELCOME_REPROMT');
            this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
        }
        console.log('Out LaunchRequest');
    },
    'IntentRequest': function () {
        console.log('IntentRequest');

        this.attributes.speechOutput = this.t('WELCOME_MESSAGE', this.t('SKILL_NAME'));
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = this.t('WELCOME_REPROMT');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'UpdateSettings': function () {
        console.log('UpdateSettings');
        var beginURL = STurl + 'update?access_token=' + STtoken; //+ '&ttstext=' + this.event.request.intent.slots.ttstext.value + '&intentName=' + this.event.request.intent.name;
        var self = this;
        https.get(beginURL, function(res) {
            console.error("Got response: " + res.statusCode);
            res.on("data", function(data) {
            console.error("BODY: " + data);
            var startJSON = JSON.parse(data);
            process.env.allESSettings = startJSON.allESSettings;
            self.emit(':tell', self.t('SETTINGS_UPDATED'));
        });
        }).on('error', function(e) {
            console.error("Got error: " + e.message);
            self.emit(':tell', self.t('ERROR'));
        });
    },    
    /*'mDetails': function () {
        console.log('UpdateSettings');
        const itemSlot = this.event.request.intent.slots.Item;
        let itemName;
        if (itemSlot && itemSlot.value) {
            itemName = itemSlot.value.toLowerCase();
        }

        var rStartingDate = event.request.intent.slots.startingD.value;
        var rStartingTime = event.request.intent.slots.startingT.value;
        var rDuration = event.request.intent.slots.duration.value;
        var rProfile = event.request.intent.slots.profile.value;

        //const cardTitle = this.t('DISPLAY_CARD_TITLE', this.t('SKILL_NAME'), itemName);
        //const myRecipes = this.t('RECIPES');
        //const recipe = myRecipes[itemName];

        if (recipe) {
            this.attributes.speechOutput = recipe;
            this.attributes.repromptSpeech = this.t('RECIPE_REPEAT_MESSAGE');
            this.emit(':askWithCard', recipe, this.attributes.repromptSpeech, cardTitle, recipe);
        } else {
            let speechOutput = this.t('RECIPE_NOT_FOUND_MESSAGE');
            const repromptSpeech = this.t('RECIPE_NOT_FOUND_REPROMPT');
            if (itemName) {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITH_ITEM_NAME', itemName);
            } else {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME');
            }
            speechOutput += repromptSpeech;

            this.attributes.speechOutput = speechOutput;
            this.attributes.repromptSpeech = repromptSpeech;

            this.emit(':ask', speechOutput, repromptSpeech);
        }
    },*/
    'AMAZON.HelpIntent': function () {
        console.log('HelpIntent');
        this.attributes.speechOutput = this.t('HELP_MESSAGE');
        this.attributes.repromptSpeech = this.t('HELP_REPROMT');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.RepeatIntent': function () {
        console.log('RepeatIntent');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.StopIntent': function () {
        console.log('StopIntent');
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function () {
        console.log('CancelIntent');
        this.emit('SessionEndedRequest');
    },
    'SessionEndedRequest': function () {
        console.log('SessionEndedRequest');
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'Unhandled': function () {
        console.log('Unhandled');
        if (process.env.allESSettings === undefined || process.env.allESSettings === '' || process.env.allESSettings === 'empty') {
            this.emitWithState('UpdateSettings');
        } else {
            this.attributes.speechOutput = this.t('HELP_MESSAGE');
            this.attributes.repromptSpeech = this.t('HELP_REPROMPT');
            this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
        }
    },
};

exports.handler = function (event, context, callback) {
    
    //this.event.context.System.device.deviceId
    
    console.log('Before ' + process.env.allESSettings);    
    //console.log('Intent '+ event.request.intent.name);
    
    const alexa = Alexa.handler(event, context, callback);
    //alexa.APP_ID = undefined;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);

    alexa.execute();
    console.log('After ' + process.env.allESSettings); 
};