/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.0.00 - 9/24/2017 Complete Overhaul using the Alexa-SDK!
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
var alexa;
const https = require('https');
const aws = require('aws-sdk');
/*const ddb = new aws.DynamoDB({
  apiVersion: '2012-08-10'
});*/
const stHost = process.env.stHost.split(':')[0];
const stPort = process.env.stHost.split(':')[1];
const stPath = process.env.stPath;

const commandKeywords = {
  unlock: ['unlock', 'unlocked', 'unlocking'],
  lock: ['lock', 'locked', 'locking'],
  off: ['off', 'stop', 'cancel', 'disable', 'disengage', 'kill', 'close', 'silence', 'quit', 'end'],
  on: ['on', 'start', 'enable', 'engage', 'open', 'begin'],
  more: ['increase', 'more', 'too dark', 'not bright enough', 'brighten', 'brighter', 'turn up'],
  less: ['darker', 'too bright', 'dim', 'dimmer', 'decrease', 'lower', 'low', 'softer', 'less'],
  feedback: ['give', 'for', 'tell', 'what', 'how', 'is', 'when', 'which', 'are', 'how many', 'check', 'who', 'status'],
  delay: ['delay', 'wait', 'until', 'after', 'around', 'within', 'about', 'for'] //TODO need to add the word 'in' and these keywords require a value
};

//TODO update this list based on testing
const deviceAttributes = {
  lock: ['lock'],
  door: ['door', 'garage'], //'window', 'shade', 'curtain', 'blind', 'tstat', 'indoor', 'outdoor', 'vent', 'valve', 'water', 'speaker', 'synth', 'media', 'relay'
  switch: ['light', 'switch', 'fan', 'outlet', 'relay'],
  contact: ['window', 'door', 'window']
};

const SKILL_NAME = 'EchoSistant';
const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const REPROMPT_SPEECH = 'Anything else?';
const EXIT_SKILL_MESSAGE = 'Goodbye';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';
const SETTINGS_UPDATED = 'I have updated your settings.';
const ERROR = 'Something went wrong';

exports.handler = function (event, context, callback) {
  if (event.path !== undefined) {
    //API call

    if (event.path == '/devData') {
      /*
            var errors;
            var results;
            let RequestItems = JSON.parse(event.body);
            let tableName = Object.keys(RequestItems).map(i => RequestItems[i]);
            console.log(tableName);
            var theItems = tableName[0].devData;

            var updatedevData = function(insertItems) {
              var itemsToInsert = insertItems.splice(0, 25);
              console.log('Spliced:' + itemsToInsert.length);
              var params = {
                RequestItems: {
                  devData: itemsToInsert
                }
              };
              ddb.batchWriteItem(params, function(err, data) {
                if (err) {
                  console.log('error: ' + err);
                } else {
                  console.log(data);
                  if (insertItems.length > 0) {
                    updatedevData(insertItems);
                  }
                }
              });
            };
            console.log('Start amount', theItems.length);
            updatedevData(theItems);
      */
    } else if (event.path == '/esData') {
      var doc = new aws.DynamoDB.DocumentClient({
        apiVersion: '2012-08-10',
        convertEmptyValues: true
      });
      doc.put(JSON.parse(event.body), function (err, data) {
        if (err) {
          console.log('Error during DynamoDB put:' + err);
        }
        callback(err, data);
      });
    }

    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        context: context,
        event: event
      })
    });
    /*
    const done = (err, res) => callback(null, {
      statusCode: err ? '400' : '200',
      body: err ? err.message : JSON.stringify(res),
      headers: {
        'Content-Type': 'application/json',
      },
    });
*/
  } else {
    //Alexa Skill call
    alexa = Alexa.handler(event, context, callback);
    alexa.dynamoDBTableName = 'EchoSistantV5';
    alexa.registerHandlers(handlers);
    alexa.execute();
  }
};

function callST(bodyData, callback) {
  console.log('callST');
  var options;
  if (bodyData !== '') {
    var postHeaders = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(bodyData, 'utf8')
    };
    options = {
      host: stHost,
      path: stPath,
      port: stPort,
      method: 'POST',
      headers: postHeaders
    };
  } else {
    options = {
      host: stHost,
      path: stPath,
      port: stPort,
      method: 'GET'
    };
  }
  var req = https.request(options, res => {
    res.setEncoding('utf-8');
    var result = '';
    res.on('data', data => {
      result += data;
    });
    res.on('end', function () {
      callback(result);
    });
  });
  req.write(bodyData);
  req.end();
  req.on('error', e => {
    console.log('HTTP error: ' + e.message);
  });
}

const handlers = {
  LaunchRequest: function () {
    console.log('LaunchRequest');
    //Called the Invocation word without an intent....

    this.attributes.speechOutput = WELCOME_MESSAGE;
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    this.attributes.repromptSpeech = WELCOME_REPROMT;
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  IntentRequest: function () {
    console.log('IntentRequest');
    //Called the invocation word with an intent...
    // this.event.request.intent.name = the profile name

    this.emitWithState(this.event.request.intent.name);

    //this.attributes.speechOutput = WELCOME_MESSAGE;
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    //this.attributes.repromptSpeech = WELCOME_REPROMT;
    //this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  'AMAZON.HelpIntent': function () {
    console.log('HelpIntent');
    this.attributes.speechOutput = HELP_MESSAGE;
    this.attributes.repromptSpeech = HELP_REPROMT;
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  'AMAZON.RepeatIntent': function () {
    console.log('RepeatIntent');
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  'AMAZON.StopIntent': function () {
    console.log('StopIntent');
    this.emit('SessionEndedRequest');
  },
  'AMAZON.CancelIntent': function () {
    console.log('CancelIntent');
    this.emit('SessionEndedRequest');
  },
  SessionEndedRequest: function () {
    console.log('SessionEndedRequest');
    this.emit(':saveState', true);
    this.emit(':tell', STOP_MESSAGE);
  },
  Unhandled: function () {
    console.log('Unhandled');

    let theCommand = this.event.request.intent.slots.ttstext.value.toLowerCase();
    let theRoom = this.event.request.intent.name;
    let theDevices = [];
    let theDevice = '';
    let theActions = [];
    /*
        //Search for keywords
        for (let keyword in commandKeywords) {
          findMatch(theCommand, '\\b' + keyword + '\\b', function(result) {
            if (result) {
              theActions.push(keyword);
            }
          });
        }

        theDevice = findDevices('Fan', function(err, results) {
          console.log(err, results);
        });




          let devices = this.deviceData;
          let deviceNames = devices.map(d => d.label);
          let roomNames = [...new Set(devices.map(r => r.rooms).reduce((a, b) => a.concat(b)))];

          let theCommand = this.event.request.intent.slots.ttstext.value.toLowerCase();
          let theDevices = [];
          let theDevice = '';
          let theActions = [];



          //Search for individual devices
          for (let [device, deviceName] of deviceNames.entries()) {
            findMatch(theCommand, '\\b' + deviceName.toLowerCase() + '\\b', function (result) {
              if (result) {
                if (deviceName.length > theDevice.length) {
                  for (let theAction of theActions) {
                    findMatch(devices[device].commands, '\\b' + theAction + '(?:es|s)?\\b', function (result) {
                      if (result) {
                        theDevice = deviceName;
                        theDevices = [devices[device].id];
                        theActions = [theAction];
                      }
                    });
                  }
                }
              }
            });
          }

          // If they spoke of an individual device then we ignore everything else and just work with that device alone otherwise keep parsing
          if (theDevices.length === 0) {
            //Tweak this section to see if they mentioned a room name. Figure out which one takes priority, the invocation word or the word spoken.
            //Might need to find multiple rooms in the future....
            for (let [room, roomName] of roomNames.entries()) {
              findMatch(theCommand, '\\b' + roomName.toLowerCase() + '\\b', function (result) {
                if (result) {
                  theRoom = roomName;
                }
              });
            }

            //Find all devices in the room that have the keyword action (on, off, etc)
            for (let deviceType in deviceAttributes) {
              if (deviceAttributes[deviceType].find(it => theCommand.includes(it))) {
                theDevices = theDevices.concat(
                  devices.filter(room => room.rooms.toString().toLowerCase().includes(theRoom.toLowerCase())).filter(attribute => attribute.attributes.includes(deviceType)).map(d => d.id)
                );
              }
            }
          }
    */
    let processData = JSON.stringify({
      theRoom: theRoom,
      theActions: theActions,
      theDevices: theDevices,
      theDelay: 0,
      deviceId: this.event.context.System.device.deviceId,
      requestId: this.event.request.requestId,
      sessionId: this.event.session.sessionId,
      theCommand: theCommand
    });

    console.log(processData);
    var self = this;
    //      callST(processData, function (response) {
    //depending on response, have alexa respond accordingly
    this.emit(':tell', 'ok');
    //      });
  }
};

var findDevices = function (deviceNames, callback) {
  var docClient = new aws.DynamoDB.DocumentClient();
  var params = {
    TableName: 'devData',
    ProjectionExpression: 'deviceId, label, rooms, commands',
    FilterExpression: 'contains(label, :labelValue)',
    ExpressionAttributeValues: {
      ':labelValue': deviceNames
    }
  };
  var items = [];
  var scanExecute = function (callback) {
    docClient.scan(params, function (err, result) {
      if (err) {
        callback(err);
      } else {
        items = items.concat(result.Items);
        if (result.LastEvaluatedKey) {
          params.ExclusiveStartKey = result.LastEvaluatedKey;
          scanExecute(callback);
        } else {
          callback(err, items);
        }
      }
    });
  };
  scanExecute(callback);
};

var findDevices2 = function (label, callback) {
  var params = {
    TableName: 'devData',
    ProjectionExpression: '#deviceId, label, rooms, command',
    FilterExpression: '#label IN (:labelValue)',
    ExpressionAttributeNames: {
      '#label': 'label'
    },
    ExpressionAttributeValues: {
      ':labelValue': label
    }
  };
  var items = [];
  var queryExecute = function (callback) {
    ddb.query(params, function (err, result) {
      if (err) {
        callback(err);
      } else {
        console.log(result);
        items = items.concat(result.Items);
        if (result.LastEvaluatedKey) {
          params.ExclusiveStartKey = result.LastEvaluatedKey;
          queryExecute(callback);
        } else {
          callback(err, items);
        }
      }
    });
  };
  queryExecute(callback);
};

function findMatch(searchIn, theMatch, callBack) {
  let results;
  let regEx = new RegExp(theMatch);
  if (typeof searchIn == 'object') {
    for (let item of searchIn) {
      if (regEx.test(item)) {
        results = item;
      }
    }
  } else {
    if (regEx.test(searchIn)) {
      results = true;
    }
  }
  callBack(results);
}