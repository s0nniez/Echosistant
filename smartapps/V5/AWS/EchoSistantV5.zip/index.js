/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
var alexa;

const WELCOME_MESSAGE = 'Welcome to the Echosistant Evolution Skill.  Please give me a command.';
const WELCOME_REPROMT = 'I need a command before i can be of any help. What can i help you with?';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = getRandomItem(['I am here if you need me', 'hopefully i will talk to you soon', 'fine i will leave you alone', 'suit yourself']);

var cardTitle = 'EchoSistant Evolution';
var cardContent = '';

var appLogo = {
    smallImageUrl: 'https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png',
    largeImageUrl: 'https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png'
};

exports.handler = function(event, context, callback) {
    if (event.path === '/esData') {
        esUtils.handleDbUpdates(event.body, function(err, response) {
            callback(null, {
                statusCode: 200,
                body: JSON.stringify({
                    lambdaInfo: response
                })
            });
        });
    } else {
        //Alexa Skill call
        alexa = Alexa.handler(event, context, callback);
        alexa.dynamoDBTableName = 'EchoSistantV5';
        alexa.registerHandlers(alexaHandlers);
        alexa.execute();
    }
};

const alexaHandlers = {
    LaunchRequest: function() {
        console.error('ESLogging| LaunchRequest');
        this.attributes.speechOutput = WELCOME_MESSAGE;
        this.attributes.repromptSpeech = WELCOME_REPROMT;
        this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
    },
    IntentRequest: function() {
        console.log('ESLogging| IntentRequest:', this.event.request.intent.name);
        this.emit(this.event.request.intent.name);
    },
    'AMAZON.HelpIntent': function() {
        this.attributes.speechOutput = HELP_MESSAGE;
        this.attributes.repromptSpeech = HELP_REPROMT;
        this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
    },
    'AMAZON.RepeatIntent': function() {
        this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
    },
    'AMAZON.StopIntent': function() {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function() {
        this.emit('SessionEndedRequest');
    },
    SessionEndedRequest: function() {
        console.error('ESLogging| SessionEndedRequest');
        this.attributes.usingHere = undefined;
        this.emit(':tellWithCard', STOP_MESSAGE, cardTitle, STOP_MESSAGE, appLogo);
    },
    Here: function() {
        console.error('ESLogging| Here');
        if (this.attributes.deviceProfile === undefined) {
            if (this.attributes.usingHere === undefined) {
                this.attributes.usingHere = 'FirstCall';
            }
            esUtils.handleHere.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    },
    UpdateSettings: function() {
        console.error("ESLogging| UpdateSetttings");
        if (this.attributes.configModeStage !== undefined || this.attributes.configModeStage !== "needSetValue") {
            this.attributes.configModeStage = "needSetName";
        }
        let respStr = "Which setting are we modifying? To list the available options, say list settings.";
        this.emit(':ask', respStr); //, cardTitle, respStr, appLogo);
    },
    Unhandled: function() {
        console.error("ESLogging| Unhandled | ttstext: (" + this.event.request.intent.slots.ttstext.value + ")");
        var self = this;
        if (this.attributes.usingHere !== undefined) {
            esUtils.handleHere.call(this);
        } else if (this.attributes.configModeStage !== undefined) {
            esUtils.handleSettings(self, function(err, type, response) {
                self.emit(type, response); //, cardTitle, response, appLogo);
            });
        } else {
            if (this.event.request.intent.slots.ttstext.value.match(/\bsend debug log\b/i)) {
                console.log('Sending Debug Log');
                esUtils.sendDebugLogs.call(this);
            } else {
                esUtils.findDevices.call(this);
            }
        }
    }
};

function getRandomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
}

//============================================================================== 
//=================== SHOW TEMPLATE HELPER FUNCTIONS  ========================== 
//============================================================================== 
function buildVoiceCardObject(handlerObj, speechOutput, templateToken, askOrTell, renderCardContent, displayRepromptText, funcCardTitle, simpleCardContent, bodyTemplateTitle, bodyTemplateContent) {
    if (supportsDisplay.call(handlerObj) || isSimulator.call(handlerObj)) {
        console.log("has display:" + supportsDisplay.call(handlerObj));
        console.log("is simulator:" + isSimulator.call(handlerObj));
        var content = {
            "hasDisplaySpeechOutput": speechOutput,
            "hasDisplayRepromptText": displayRepromptText,
            "simpleCardTitle": funcCardTitle,
            "simpleCardContent": simpleCardContent,
            "bodyTemplateTitle": bodyTemplateTitle,
            "bodyTemplateContent": bodyTemplateContent,
            "templateToken": templateToken,
            "sideImage": "https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png",
            "backgroundImage": "https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png",
            "askOrTell": askOrTell,
            "sessionAttributes": {}
        };
        renderTemplate.call(handlerObj, content);
    } else {
        // Just use a card if the device doesn't support a card. 
        handlerObj.response.cardRenderer(funcCardTitle, renderCardContent);
        handlerObj.response.speak(speechOutput);
        handlerObj.emit(':responseReady');
    }
}


function supportsDisplay() {
    var hasDisplay =
        this.event.context &&
        this.event.context.System &&
        this.event.context.System.device &&
        this.event.context.System.device.supportedInterfaces &&
        this.event.context.System.device.supportedInterfaces.Display
    return hasDisplay;
}

function isSimulator() {
    var isSimulator = !this.event.context; //simulator doesn't send context 
    return isSimulator;
}

function renderTemplate(content) {
    switch (content.templateToken) {
        case "factBodyTemplate":
            var response = {
                "version": "1.0",
                "response": {
                    "directives": [{
                        "type": "Display.RenderTemplate",
                        "template": {
                            "type": "BodyTemplate1",
                            "title": content.bodyTemplateTitle,
                            "token": content.templateToken,
                            "textContent": {
                                "primaryText": {
                                    "type": "RichText",
                                    "text": "<font size = '5'>" + content.bodyTemplateContent + "</font>"
                                }
                            },
                            "backButton": "HIDDEN"
                        }
                    }],
                    "outputSpeech": {
                        "type": "SSML",
                        "ssml": "<speak>" + content.hasDisplaySpeechOutput + "</speak>"
                    },
                    "reprompt": {
                        "outputSpeech": {
                            "type": "SSML",
                            "ssml": "<speak>" + content.hasDisplayRepromptText + "</speak>"
                        }
                    },
                    "shouldEndSession": content.askOrTell == ":tell",
                    "card": {
                        "type": "Simple",
                        "title": content.simpleCardTitle,
                        "content": content.simpleCardContent
                    }
                },
                "sessionAttributes": content.sessionAttributes
            }
            this.context.succeed(response);
            break;

        case "deviceCmdTemplate":
            var response = {
                "version": "1.0",
                "response": {
                    "directives": [{
                        "type": "Display.RenderTemplate",
                        "template": {
                            "type": "BodyTemplate3",
                            "token": content.templateToken,
                            "backgroundImage": content.backgroundImage,
                            "title": content.bodyTemplateTitle,
                            "image": content.sideImage,
                            "textContent": {
                                "primaryText": {
                                    "type": "RichText",
                                    "text": "<font size = '5'>" + content.bodyTemplateContent + "</font>"
                                }
                            },
                            "backButton": "HIDDEN"
                        }
                    }],
                    "outputSpeech": {
                        "type": "SSML",
                        "ssml": "<speak>" + content.hasDisplaySpeechOutput + "</speak>"
                    },
                    "reprompt": {
                        "outputSpeech": {
                            "type": "SSML",
                            "ssml": "<speak>" + content.hasDisplayRepromptText + "</speak>"
                        }
                    },
                    "shouldEndSession": content.askOrTell == ":tell",
                    "card": {
                        "type": "Simple",
                        "title": content.simpleCardTitle,
                        "content": content.simpleCardContent
                    }
                },
                "sessionAttributes": content.sessionAttributes
            }
            this.context.succeed(response);
            break;

        default:
            this.response.speak("Thanks for chatting, goodbye");
            this.emit(':responseReady');
    }
}