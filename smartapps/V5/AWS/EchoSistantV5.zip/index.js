/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.0.0904 - 9/04/2017 Complete Overhaul using the Alexa-SDK!
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
var alexa;
const https = require('https');
const aws = require('aws-sdk');
const stHost = process.env.stHost.split(':')[0];
const stPort = process.env.stHost.split(':')[1];
const stPath = process.env.stPath;
const stAppID = process.env.stPath.split('/')[4];
const devName = '';
const appVersion = '5.0.0904';
const appVerDate = '9/04/2017';

var states = {
	RESPONSE: '_RESPONSE',
	STARTMODE: '_STARTMODE'
};

const SKILL_NAME = 'EchoSistant';
const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const REPROMPT_SPEECH = 'Anything else?';
const EXIT_SKILL_MESSAGE = 'Goodbye';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';
const SETTINGS_UPDATED = 'I have updated your settings.';
const ERROR = 'Something went wrong';

exports.handler = function(event, context, callback) {
	if (event.path !== undefined) {
		//API call

		if (event.path == '/esData') {
			var doc = new aws.DynamoDB.DocumentClient({
				apiVersion: '2012-08-10',
				convertEmptyValues: true
			});
			console.log(event.body);
			doc.put(JSON.parse(event.body), function(err, data) {
				if (err) {
					console.error('Error during DynamoDB put:' + err);
				}
				callback(err, data);
			});
		}

		callback(null, {
			statusCode: 200,
			body: JSON.stringify({
				context: context,
				event: event
			})
		});
		/*
    const done = (err, res) => callback(null, {
      statusCode: err ? '400' : '200',
      body: err ? err.message : JSON.stringify(res),
      headers: {
        'Content-Type': 'application/json',
      },
    });
*/
	} else {
		//Alexa Skill call
		alexa = Alexa.handler(event, context, callback);
		alexa.dynamoDBTableName = 'EchoSistantV5';
		alexa.registerHandlers(newSessionHandlers, startHandlers, responseHandlers);
		alexa.execute();
	}
};

const newSessionHandlers = {
	NewSession: function() {
		console.error('LaunchRequest');
		this.handler.state = states.STARTMODE;
		this.emitWithState(this.event.request.intent.name);
	}
};

const startHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
	NewSession: function() {
		console.log('NewSession in Start');
		this.handler.state = '';
		this.emitWithState('NewSession'); // Equivalent to the Start Mode NewSession handler
	},
	LaunchRequest: function() {
		console.log('LaunchRequest');
		//Called the Invocation word without an intent....
		this.attributes.speechOutput = WELCOME_MESSAGE;
		// If the user either does not reply to the welcome message or says something that is not
		// understood, they will be prompted again with this text.
		this.attributes.repromptSpeech = WELCOME_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	IntentRequest: function() {
		console.log('IntentRequest', this.event.request.intent.name);
		this.emitWithState(this.event.request.intent.name);
	},
	'AMAZON.HelpIntent': function() {
		console.log('HelpIntent', states.STARTMODE);
		this.attributes.speechOutput = HELP_MESSAGE;
		this.attributes.repromptSpeech = HELP_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.RepeatIntent': function() {
		console.log('RepeatIntent');
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.StopIntent': function() {
		console.log('StopIntent');
		this.emit('SessionEndedRequest');
	},
	'AMAZON.CancelIntent': function() {
		console.log('CancelIntent');
		this.emit('SessionEndedRequest');
	},
	SessionEndedRequest: function() {
		console.log('SessionEndedRequest');
		this.emit(':saveState', true);
		this.emit(':tell', STOP_MESSAGE);
	},
	Here: function() {
		console.error('Here', states.STARTMODE);
		console.log(alexa.theId);
		if (alexa.theId.startsWith('amzn1.ask.device')) {
			if (this.attributes.deviceProfile === undefined) {
				this.handler.state = states.RESPONSE;
				this.emit(':ask', 'In what room is this device located?', 'In what room is this device located?');
			} else {
				this.emit(':tell', 'Okay');
			}
		}
	},
	Unhandled: function() {
		console.error('Unhandled', states.STARTMODE);
		var self = this;
		if (this.event.request.intent.slots.ttstext.value.includes('send debug log')) {
			console.log('Sending Debug Log');
			sendDebugLogs(self);
		} else {
			findDevices(self);
		}
	}
});

const responseHandlers = Alexa.CreateStateHandler(states.RESPONSE, {
	NewSession: function() {
		console.error('LaunchRequest in Response');
		this.handler.state = '';
		this.emitWithState('NewSession'); // Equivalent to the Start Mode NewSession handler
	},
	LaunchRequest: function() {
		console.error('LaunchRequest');
		//Called the Invocation word without an intent....
		this.attributes.speechOutput = WELCOME_MESSAGE;
		// If the user either does not reply to the welcome message or says something that is not
		// understood, they will be prompted again with this text.
		this.attributes.repromptSpeech = WELCOME_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	IntentRequest: function() {
		console.log('IntentRequest', this.event.request.intent.name);
		this.emitWithState(this.event.request.intent.name);
	},
	'AMAZON.HelpIntent': function() {
		console.log('HelpIntent', states.RESPONSE);
		this.attributes.speechOutput = HELP_MESSAGE;
		this.attributes.repromptSpeech = HELP_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.RepeatIntent': function() {
		console.log('RepeatIntent', states.RESPONSE);
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.StopIntent': function() {
		console.log('StopIntent', states.RESPONSE);
		this.emit('SessionEndedRequest');
	},
	'AMAZON.CancelIntent': function() {
		console.log('CancelIntent', states.RESPONSE);
		this.emit('SessionEndedRequest');
	},
	SessionEndedRequest: function() {
		console.error('SessionEndedRequest', states.RESPONSE);
		this.emit(':saveState', true);
		this.emit(':tell', STOP_MESSAGE);
	},
	Here: function() {
		console.log('Here', states.RESPONSE);
		console.log('Here', states.RESPONSE);
		if (alexa.theId.startsWith('amzn1.ask.device')) {
			//this.attributes.deviceProfile === undefined)
			this.emit(':tell', 'Okay, this device now controls ' + this.event.request.intent.slots.ttstext.value);
		}
	},
	Unhandled: function() {
		console.log('Unhandled', states.RESPONSE);
		var self = this;
		if (this.event.request.intent.slots.ttstext.value.includes('send debug log')) {
			console.log('Sending Debug Log')
			sendDebugLogs(self);
		} else {
			findDevices(self);
		}
	}
});

function sendDebugLogs(theHandler) {
	var cloudwatchlogs = new aws.CloudWatchLogs({
		apiVersion: '2014-03-28'
	});
	var params = {
		logGroupName: '/aws/lambda/EchoSistantV5',
		interleaved: true
	};
	cloudwatchlogs.filterLogEvents(params, function(err, data) {
		if (err) {
			console.error(err, err.stack);
		} else {
			let payload = JSON.stringify({
				cloudWatchLogEventData: data.events,
				devName: devName,
				appVersion: appVersion,
				appVerDate: appVerDate,
				esData: theHandler.esData,
				tz: new Date().toString()
			});
			var postHeaders = {
				'Content-Type': 'application/json',
				'Content-Length': Buffer.byteLength(payload, 'utf8')
			};
			let options = {
				host: 'echosistant-analytics.firebaseio.com',
				path: '/cloudWatchLogEventData/' + stAppID + '/logs.json',
				port: '443',
				method: 'PATCH',
				headers: postHeaders
			};
			console.log(options);
			webWrite(options, payload, function(err, response) {
				console.log(response);
				//if (alexa.theId.startsWith('amzn1.ask.device')) {
				//this.attributes.deviceProfile === undefined)
				theHandler.emit(':tell', 'Data Sent');
				//}
			});
		}
	});

}

function findDevices(theHandler) {
	const theCommand = cleanString(theHandler.event.request.intent.slots.ttstext.value);
	const theIntent = theHandler.event.request.intent.name;
	let theParsedCommand = theCommand;

	let theItemsFound = [];
	// Data from the dynamobd
	const devData = theHandler.esData.devData;
	const roomNames = [...new Set(devData.map((r) => r.rooms).reduce((a, b) => a.concat(b)))].map((a) => Object.assign({ theId: a, theType: 'room', toFind: cleanString(a) }));

	let devicesToSearchFor = [];
	let roomsToSearchFor = [];
	let deviceCapToSearchFor = [];
	let cmdToSearchFor = [];
	let allCmds = [];
	let allRooms = [];

	devData.forEach((device) => {
		devicesToSearchFor.push({ theId: device.deviceId, theType: 'device', toFind: cleanString(device.label) }); // real device name
		device.rooms.forEach((room) => {
			roomsToSearchFor.push({ theId: device.deviceId, theType: 'room', toFind: cleanString(room) }); // filter for deviceTypes
		});
		device.capabilities.forEach((cap) => {
			deviceCapToSearchFor.push({ theId: device.deviceId, theType: 'deviceType', toFind: cleanString(cap) }); // filter for deviceTypes
		});
		device.commands.forEach((command) => {
			let splitCmd = command.replace(/:.*/, '').split(/(?=[A-Z]+[^A-Z]?)/);
			if (splitCmd.length > 1) {
				splitCmd = splitCmd.join(' ');
			}
			cmdToSearchFor.push({ theId: device.deviceId, theType: 'command', toFind: cleanString(splitCmd.toString()) }); // filter commands
		});
	});

	// Add the intent room if its a real room and not already in the command
	if (!theCommand.includes(cleanString(theIntent))) {
		if (roomNames.some((r) => r.toFind.includes(cleanString(theIntent)))) {
			theParsedCommand += ' ' + cleanString(theIntent); // Add the intent room if its a real room and not already in the command
		}
	}

	// This collects the data we just created and concats the 3 objects together, keeping the same format and sorting them from largest to smallest
	const itemsToParse = [].concat(devicesToSearchFor, cmdToSearchFor, deviceCapToSearchFor, roomsToSearchFor).sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));

	for (let itemToFind of itemsToParse) {
		if (theParsedCommand.match('\\b' + itemToFind.toFind + 's?\\b')) {
			//theParsedCommand = theParsedCommand.replace(foundWord.toFind, '').trim();
			theItemsFound.push({ theItemFound: itemToFind, theLocation: theCommand.indexOf(itemToFind.toFind) }); // Finds every possible keyword in the command
		}
	}

	const theFoundCmds = theItemsFound.reduce((acc, curr) => {
		if (curr.theItemFound.theType === 'command') {
			//allCmds.push({cmd: curr.theItemFound.toFind, order: curr.theLocation})
			allCmds.push(curr.theItemFound.toFind);
			return acc.concat(curr);
		} else {
			return acc;
		}
	}, []);

	const theFoundDevices = theItemsFound.reduce((acc, curr) => {
		if (
			curr.theItemFound.theType === 'device' &&
			theFoundCmds
				.reduce((acc, curr) => {
					return [...acc, curr.theItemFound.theId];
				}, [])
				.includes(curr.theItemFound.theId)
		) {
			return acc.concat(curr);
		} else {
			return acc;
		}
	}, []);

	const theFoundDeviceTypes = theItemsFound.reduce((acc, curr) => {
		if (
			curr.theItemFound.theType === 'deviceType' &&
			theFoundCmds
				.reduce((acc, curr) => {
					return [...acc, curr.theItemFound.theId];
				}, [])
				.includes(curr.theItemFound.theId)
		) {
			return acc.concat(curr);
		} else {
			return acc;
		}
	}, []);

	const foundDevicesWithCmdInRoom = theItemsFound.reduce((acc, curr) => {
		if (
			curr.theItemFound.theType === 'room' &&
			theFoundCmds
				.reduce((acc, curr) => {
					return [...acc, curr.theItemFound.theId];
				}, [])
				.includes(curr.theItemFound.theId)
		) {
			allRooms.push(curr.theItemFound.theId);
			return acc.concat(curr);
		} else {
			return acc;
		}
	}, []);

	let theDevices = [];
	if (theFoundDevices.length) {
		console.log('Real Deivce Found ', theFoundDevices);
		theDevices = theFoundDevices.reduce((acc, curr) => {
			return [...acc, curr.theItemFound.theId];
		}, []);
	} else if (foundDevicesWithCmdInRoom.length) {
		console.log('DeivceType Found ', foundDevicesWithCmdInRoom);
		theDevices = foundDevicesWithCmdInRoom.reduce((acc, curr) => {
			return [...acc, curr.theItemFound.theId];
		}, []);
	} else {
		console.log('Devices in room ', theFoundDeviceTypes);
		theDevices = theFoundDeviceTypes.reduce((acc, curr) => {
			return [...acc, curr.theItemFound.theId];
		}, []);
	}

	const theActions = [...new Set(allCmds)];

	let processData = JSON.stringify({
		theRoom: theIntent,
		theActions: theActions,
		theDevices: theDevices,
		theDelay: 0,
		deviceId: theHandler.event.context.System.device.deviceId,
		requestId: theHandler.event.request.requestId,
		sessionId: theHandler.event.session.sessionId,
		theCommand: theCommand
	});

	console.log(processData);
	let postHeaders = {
		'Content-Type': 'application/json',
		'Content-Length': Buffer.byteLength(processData, 'utf8')
	};
	let options = {
		host: stHost,
		path: stPath,
		port: stPort,
		method: 'POST',
		headers: postHeaders
	};
	webWrite(options, processData, function(err, response) {
		console.log(response);
		let theResponse = JSON.parse(response);
		theHandler.emit(':tell', theResponse.ttsResp);
	});
}

function cleanString(str) {
	return str.replace(/[^A-Za-z0-9 ]/gi, '').toLowerCase(); // Better regex... the other one was missing some things...
}

function webWrite(options, bodyData, callback) {
	var req = https.request(options, (res) => {
		var result = '';
		res.on('data', (data) => {
			result += data;
		});
		res.on('end', function() {
			console.log(result);
			callback(null, result);
		});
	});
	req.write(bodyData);
	req.end();
	req.on('error', (e) => {
		console.error('HTTP error: ' + e.message);
	});
}