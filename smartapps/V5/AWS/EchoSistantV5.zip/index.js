/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.4.00 - 6/30/2017 Complete overhaul!
 *  Version 5.3.00 - 6/21/2017 Added US Skill
 *  Version 5.1.00 - 3/21/2017 Added Reminders Profile
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const https = require('https');
const STtoken = process.env.STtoken;
const STurl = process.env.STurl;
const versionTxt = '5.4';

var keywords = {
    'feedback': ['give', 'for', 'tell', 'what', 'how', 'is', 'when', 'which', 'are', 'how many', 'check', 'who', 'status'],
    'enable': ['on', 'start', 'enable', 'engage', 'open', 'begin', 'unlock', 'unlocked'],
    'disable': ['off', 'stop', 'cancel', 'disable', 'disengage', 'kill', 'close', 'silence', 'lock', 'locked', 'quit', 'end'],
    'more': ['increase', 'more', 'too dark', 'not bright enough', 'brighten', 'brighter', 'turn up'],
    'less': ['darker', 'too bright', 'dim', 'dimmer', 'decrease', 'lower', 'low', 'softer', 'less'],
    'delay': ['delay', 'wait', 'until', 'after', 'around', 'within', 'in', 'about']
};

//will eventually be a var...
var deviceTypes = {
    'switch': ['light', 'switch', 'fan', 'outlet', 'relay'],
    'lock': ['lock'],
    'door': ['door', 'garage'], //'window', 'shade', 'curtain', 'blind', 'tstat', 'indoor', 'outdoor', 'vent', 'valve', 'water', 'speaker', 'synth', 'media', 'relay'
    'contact': ['window', 'door', 'window']
};

var settings = JSON.parse('{"location":{"latitude":27.85645053,"longitude":-82.52780821,"mode":"Home","name":"Home","id":"3e783344-ce2f-45b5-bbf8-5be99f345506","temperature_scale":"F","zip_code":"33608","hubIP":"192.168.1.132","smartapp_version":"0.5.5"},"deviceList":[{"profile":"Home","name":"Front Door","basename":"NYCE Door Hinge Sensor","deviceid":"226a0377-a2ae-49b7-8fc1-21107e217f65","status":"ONLINE","groupId":"c444e46c-e850-47d9-a58d-3abeed7e50b4","manufacturerName":"NYCE","modelName":"3010","lastTime":"2017-07-11T01:05:20+0000","capabilities":{"Battery":1,"Contact Sensor":1,"Configuration":1,"Refresh":1,"Sensor":1,"Health Check":1},"commands":{"configure":[],"refresh":[],"ping":[],"enrollResponse":[]},"attributes":{"battery":25,"contact":"closed","checkInterval":7260}},{"profile":"Home","name":"Front Door Lock","basename":"Z-Wave Lock","deviceid":"5d84039e-0c2a-471e-a77f-7f950d7d153f","status":"ACTIVE","groupId":"c444e46c-e850-47d9-a58d-3abeed7e50b4","manufacturerName":null,"modelName":null,"lastTime":"2017-07-10T15:09:23+0000","capabilities":{"Battery":1,"Contact Sensor":1,"Polling":1,"Lock":1,"Refresh":1,"Smoke Detector":1,"Lock Codes":1,"Sensor":1,"Actuator":1,"Tamper Alert":1},"commands":{"poll":[],"lock":[],"unlock":[],"refresh":[],"setCode":["STRING","NUMBER","STRING"],"deleteCode":["NUMBER"],"requestCode":["NUMBER"],"reloadAllCodes":[],"unlockWithTimeout":[],"setCodeLength":["NUMBER"],"nameSlot":["NUMBER","STRING"],"updateCodes":["JSON_OBJECT"],"unlockwtimeout":[],"alarmToggle":[],"setAlarm":["STRING"],"sensitiveToggle":[],"setSensitivity":["STRING"],"disableKeypad":[],"enableKeypad":[],"enableAutolock":[],"disableAutolock":[],"disableAudio":[],"enableAudio":[]},"attributes":{"battery":100,"contact":"closed","lock":"locked","smoke":"clear","carbonMonoxide":null,"codeChanged":"2","lockCodes":null,"scanCodes":null,"codeLength":null,"maxCodes":30,"maxCodeLength":null,"minCodeLength":null,"codeReport":"2","tamper":"clear","alarm":"","sensitive":"","codeunlock":"enabled","autolock":"disabled","lockStatus":"Battery 100%","invalidCode":null,"beeper":"enabled","pinLength":4,"codeVersion":"03.03.03","dhName":"Universal Z-Wave Lock Device Handler","contactX":"unknown"}},{"profile":"Home","name":"Garage Door","basename":"NYCE Door Hinge Sensor","deviceid":"2578b104-59e8-4f30-9372-e4dd302cf408","status":"ONLINE","groupId":"69dbf695-41e3-463e-a48f-422521d1e921","manufacturerName":"NYCE","modelName":"3010","lastTime":"2017-07-11T01:08:59+0000","capabilities":{"Battery":1,"Contact Sensor":1,"Configuration":1,"Refresh":1,"Sensor":1,"Health Check":1},"commands":{"configure":[],"refresh":[],"ping":[],"enrollResponse":[]},"attributes":{"battery":75,"contact":"closed","checkInterval":720}},{"profile":"Home","name":"Garage Door Opener","basename":"Linear GoControl Garage Door Opener","deviceid":"7c0fb708-295b-47ae-a3cd-780e710a915c","status":"ONLINE","groupId":"69dbf695-41e3-463e-a48f-422521d1e921","manufacturerName":null,"modelName":null,"lastTime":"2017-07-11T01:05:02+0000","capabilities":{"Contact Sensor":1,"Refresh":1,"Sensor":1,"Actuator":1,"Door Control":1,"Garage Door Control":1,"Health Check":1},"commands":{"refresh":[],"open":[],"close":[],"ping":[]},"attributes":{"contact":"closed","door":"closed","checkInterval":1920}},{"profile":"Home","name":"Garage Keypad","basename":"Iris 3405-L Keypad","deviceid":"49ca789e-37e4-4fb2-85dc-e3c29212d28d","status":"ONLINE","groupId":"69dbf695-41e3-463e-a48f-422521d1e921","manufacturerName":"CentraLite","modelName":"3405-L","lastTime":"2017-07-11T00:44:56+0000","capabilities":{"Temperature Measurement":1,"Battery":1,"Motion Sensor":1,"Configuration":1,"Tone":1,"Refresh":1,"Button":1,"Lock Codes":1,"Health Check":1,"Tamper Alert":1},"commands":{"configure":[],"beep":[],"refresh":[],"lock":[],"unlock":[],"setCode":["STRING","STRING","NUMBER"],"deleteCode":["NUMBER"],"requestCode":["NUMBER"],"reloadAllCodes":[],"unlockWithTimeout":[],"setCodeLength":["NUMBER"],"nameSlot":["STRING","NUMBER"],"updateCodes":["JSON_OBJECT"],"ping":[],"setDisarmed":[],"setArmedAway":[],"setArmedStay":[],"setArmedNight":[],"setExitDelay":["NUMBER"],"setEntryDelay":["NUMBER"],"sendInvalidKeycodeResponse":[],"acknowledgeArmRequest":[],"enrollResponse":[]},"attributes":{"temperature":76,"battery":100,"motion":"inactive","button":null,"numberOfButtons":null,"lock":null,"codeChanged":null,"lockCodes":null,"scanCodes":null,"codeLength":null,"maxCodes":null,"maxCodeLength":null,"minCodeLength":null,"codeReport":null,"checkInterval":7260,"tamper":"clear","armMode":"disarmed","lastUpdate":"Fri, Jun 16 2017 @ 5:19 PM EDT"}},{"profile":"Master","name":"Master Closet Motion","basename":"Iris Motion Sensor","deviceid":"48627f5e-ce5e-49a8-b57f-b7b3e0da8020","status":"ONLINE","groupId":"8a562db9-b351-40fe-a0fa-aa0bc15d0171","manufacturerName":"CentraLite","modelName":"3326-L","lastTime":"2017-07-11T01:04:38+0000","capabilities":{"Temperature Measurement":1,"Battery":1,"Motion Sensor":1,"Configuration":1,"Refresh":1,"Sensor":1,"Health Check":1},"commands":{"configure":[],"refresh":[],"ping":[],"enrollResponse":[]},"attributes":{"temperature":72,"battery":78,"motion":"inactive","checkInterval":720}},{"profile":"Office","name":"Test","basename":"Iris Contact Sensor","deviceid":"2720be92-9253-4b21-8c43-db83c0ecb4dd","status":"ONLINE","groupId":"49c61fd2-6ccc-4255-abb1-d9fac98032c7","manufacturerName":"CentraLite","modelName":"3320","lastTime":"2017-07-11T01:04:24+0000","capabilities":{"Temperature Measurement":1,"Battery":1,"Contact Sensor":1,"Configuration":1,"Refresh":1,"Sensor":1,"Health Check":1},"commands":{"configure":[],"refresh":[],"ping":[],"enrollResponse":[]},"attributes":{"temperature":78,"battery":89,"contact":"open","checkInterval":720,"status":"open"}},{"profile":"Kitchen","name":"Living Room Glass Break","basename":"Utilitech Glass Break Sensor","deviceid":"a3b3ea16-e083-4bb1-bc3b-94ac05b2377d","status":"ONLINE","groupId":"2c639f70-1f7f-4a0d-a897-2989cec1f83e","manufacturerName":null,"modelName":null,"lastTime":"2017-07-11T00:59:35+0000","capabilities":{"Battery":1,"Contact Sensor":1,"Alarm":1,"Refresh":1,"Health Check":1},"commands":{"off":[],"strobe":[],"siren":[],"both":[],"refresh":[],"ping":[]},"attributes":{"battery":67,"contact":"closed","alarm":null,"checkInterval":14520,"alarmState":null}},{"profile":"Kitchen","name":"Garage Siren","basename":"Z-Wave Siren","deviceid":"8896bf36-5c01-4ced-b51f-927441cac874","status":"ONLINE","groupId":"69dbf695-41e3-463e-a48f-422521d1e921","manufacturerName":null,"modelName":null,"lastTime":"2017-07-10T21:19:48+0000","capabilities":{"Switch":1,"Battery":1,"Alarm":1,"Configuration":1,"Refresh":1,"Sensor":1,"Actuator":1,"Health Check":1},"commands":{"on":[],"off":[],"strobe":[],"siren":[],"both":[],"configure":[],"refresh":[],"ping":[]},"attributes":{"switch":"off","battery":100,"alarm":"off","checkInterval":14520,"alarmState":"standing by"}},{"profile":"Home","name":"AC Water Sensor","basename":"Iris Smart Water Sensor","deviceid":"a7ae6a36-5287-4767-bf4a-704d46d6e254","status":"ONLINE","groupId":"b32e6b95-7935-4959-847b-af481dae0a99","manufacturerName":"CentraLite","modelName":"3315-L","lastTime":"2017-07-11T01:05:58+0000","capabilities":{"Temperature Measurement":1,"Battery":1,"Water Sensor":1,"Configuration":1,"Refresh":1,"Sensor":1,"Health Check":1},"commands":{"configure":[],"refresh":[],"ping":[],"enrollResponse":[]},"attributes":{"temperature":71,"battery":67,"water":"dry","checkInterval":720}},{"profile":"Office","name":"Desk Lamp","basename":"Desk Lamp (Hue Extended Color)","deviceid":"5bf37f31-346f-49bd-b7a5-79f4f0e5a20d","status":"ONLINE","groupId":"49c61fd2-6ccc-4255-abb1-d9fac98032c7","manufacturerName":null,"modelName":"LCT001","lastTime":null,"capabilities":{"Switch":1,"Switch Level":1,"Refresh":1,"Color Control":1,"Sensor":1,"Actuator":1,"Color Temperature":1,"Health Check":1,"Light":1},"commands":{"on":[],"off":[],"setLevel":["NUMBER","NUMBER"],"refresh":[],"setHue":["NUMBER"],"setSaturation":["NUMBER"],"setColor":["COLOR_MAP"],"setColorTemperature":["NUMBER"],"ping":[],"setAdjustedColor":[]},"attributes":{"switch":"off","level":48,"hue":52,"saturation":100,"color":"#F4FCFF","colorTemperature":6536,"checkInterval":null}},{"profile":"Kitchen","name":"Dining Room Light","basename":"Z-Wave Relay","deviceid":"dc23d52e-b554-49b0-b0db-e5e86bd9a081","status":"ACTIVE","groupId":"95532e31-bbb7-4aa1-b374-bf4ecfa27a76","manufacturerName":null,"modelName":null,"lastTime":"2017-07-10T22:39:34+0000","capabilities":{"Switch":1,"Polling":1,"Refresh":1,"Sensor":1,"Actuator":1,"Relay Switch":1},"commands":{"on":[],"off":[],"poll":[],"refresh":[]},"attributes":{"switch":"off"}},{"profile":"Home","name":"Addy\'s Fan","basename":"GE In-Wall Smart Fan Control","deviceid":"8e5a8d25-b238-4ae2-8104-b3cdbdff6699","status":"ONLINE","groupId":"a5c9f7d4-574a-4fb1-811c-bd594f330d23","manufacturerName":null,"modelName":null,"lastTime":"2017-07-11T01:08:05+0000","capabilities":{"Switch":1,"Polling":1,"Switch Level":1,"Refresh":1,"Indicator":1,"Sensor":1,"Actuator":1,"Health Check":1},"commands":{"on":[],"off":[],"poll":[],"setLevel":["NUMBER","NUMBER"],"refresh":[],"indicatorWhenOn":[],"indicatorWhenOff":[],"indicatorNever":[],"ping":[],"lowSpeed":[],"medSpeed":[],"highSpeed":[]},"attributes":{"switch":"on","level":33,"indicatorStatus":"when off","checkInterval":1920,"currentState":"LOW","currentSpeed":"LOW"}},{"profile":"Office","name":"Fan Light","basename":"KOF Zigbee Fan Controller - Light Child Device","deviceid":"f40b0f3c-cd12-484b-bef0-0e9ff6f10f65","status":"INACTIVE","groupId":"49c61fd2-6ccc-4255-abb1-d9fac98032c7","manufacturerName":null,"modelName":null,"lastTime":null,"capabilities":{"Switch":1,"Switch Level":1,"Sensor":1,"Actuator":1,"Light":1},"commands":{"on":[],"off":[],"setLevel":["NUMBER","NUMBER"]},"attributes":{"switch":"on","level":29}},{"profile":"Kitchen","name":"Living Room Fan","basename":"GE Wall Switch","deviceid":"cc9dc773-cba0-4753-b35c-f80acf85c10e","status":"ONLINE","groupId":"2c639f70-1f7f-4a0d-a897-2989cec1f83e","manufacturerName":null,"modelName":null,"lastTime":"2017-07-11T01:08:06+0000","capabilities":{"Switch":1,"Polling":1,"Refresh":1,"Indicator":1,"Sensor":1,"Actuator":1,"Health Check":1,"Light":1},"commands":{"on":[],"off":[],"poll":[],"refresh":[],"indicatorWhenOn":[],"indicatorWhenOff":[],"indicatorNever":[],"ping":[]},"attributes":{"switch":"off","indicatorStatus":"when off","checkInterval":1920}},{"profile":"Master","name":"Master Bathroom Lights","basename":"GE Wall Switch","deviceid":"c7c4c9ab-772c-4bf6-ac9e-b0a4f2137a75","status":"ONLINE","groupId":"8a562db9-b351-40fe-a0fa-aa0bc15d0171","manufacturerName":null,"modelName":null,"lastTime":"2017-07-11T01:08:01+0000","capabilities":{"Switch":1,"Polling":1,"Refresh":1,"Indicator":1,"Sensor":1,"Actuator":1,"Health Check":1,"Light":1},"commands":{"on":[],"off":[],"poll":[],"refresh":[],"indicatorWhenOn":[],"indicatorWhenOff":[],"indicatorNever":[],"ping":[]},"attributes":{"switch":"off","indicatorStatus":"when off","checkInterval":1920}},{"profile":"Office","name":"Office Fan","basename":"KOF Zigbee Fan Controller","deviceid":"06cd80e0-5bbc-43b8-add0-d203525f2007","status":"ACTIVE","groupId":"49c61fd2-6ccc-4255-abb1-d9fac98032c7","manufacturerName":"King Of Fans,  Inc.","modelName":"HDC52EastwindFan","lastTime":"2017-07-11T01:09:12+0000","capabilities":{"Switch":1,"Polling":1,"Configuration":1,"Refresh":1,"Sensor":1,"Actuator":1,"Light":1},"commands":{"on":[],"off":[],"poll":[],"configure":[],"refresh":[],"lightOn":[],"lightOff":[],"lightLevel":[],"setFanSpeed":[]},"attributes":{"switch":"on","fanMode":"03","lightBrightness":29,"lastFanMode":"03","LchildVer":"ver 0.2.170515a","FchildVer":"ver 0.2.170515","LchildCurr":"2","FchildCurr":"2"}},{"profile":"Home","name":"Not Used Yet","basename":"Not Used Yet (Hue Extended Color)","deviceid":"15fd1f06-c7ea-4c09-adbc-9d0c7d5164e4","status":"OFFLINE","groupId":"c444e46c-e850-47d9-a58d-3abeed7e50b4","manufacturerName":null,"modelName":"LCT001","lastTime":null,"capabilities":{"Switch":1,"Switch Level":1,"Refresh":1,"Color Control":1,"Sensor":1,"Actuator":1,"Color Temperature":1,"Health Check":1,"Light":1},"commands":{"on":[],"off":[],"setLevel":["NUMBER","NUMBER"],"refresh":[],"setHue":["NUMBER"],"setSaturation":["NUMBER"],"setColor":["COLOR_MAP"],"setColorTemperature":["NUMBER"],"ping":[],"setAdjustedColor":[]},"attributes":{"switch":"off","level":1,"hue":0,"saturation":0,"color":"#FFFFFF","colorTemperature":null,"checkInterval":null}}]}');

/*
for (var keyword in keywords) {
    if (keywords[keyword].find((it) => theCommand.includes(it))) {
        console.log(keyword);
    }
}
*/

const SKILL_NAME = 'EchoSistant';
const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const REPROMPT_SPEECH = 'Anything else?';
const EXIT_SKILL_MESSAGE = 'Goodbye';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';
const SETTINGS_UPDATED = 'I have updated your settings.';
const ERROR = 'Something went wrong';


const handlers = {
    'NewSession': function () {
        console.log('NewSession');
        if (Object.keys(this.attributes).length === 0) {
            //First time user has called so we need to update settings
            this.emitWithState('UpdateSettings');
        } else {
            //Settings have already been setup, so we call the request type
            this.emitWithState(this.event.request.type);
        }
    },
    'LaunchRequest': function () {
        console.log('LaunchRequest');
        //Called the Invocation word without an intent....


        this.attributes.speechOutput = WELCOME_MESSAGE;
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = WELCOME_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'IntentRequest': function () {
        console.log('IntentRequest');
        //Called the invocation word with an intent...
        // this.event.request.intent.name = the profile name

        this.attributes.speechOutput = WELCOME_MESSAGE;
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = WELCOME_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'UpdateSettings': function () {
        console.log('UpdateSettings');
        var beginURL = STurl + 'update?access_token=' + STtoken;
        this.attributes.allESSettings = '';
        var self = this;
        https.get(beginURL, function (res) {
            console.error("Got response: " + res.statusCode);
            res.on("data", function (data) {
                var getJSON = JSON.parse(data);
                self.attributes.allESSettings = getJSON.data;
                if (self.event.request.intent.name == 'UpdateSettings') {
                    self.emit(':tell', SETTINGS_UPDATED);
                } else {
                    self.emitWithState(self.event.request.type);
                }
            });
        }).on('error', function (e) {
            console.error("Got error: " + e.message);
            self.emit(':tell', ERROR);
        });
    },
    'AMAZON.HelpIntent': function () {
        console.log('HelpIntent');
        this.attributes.speechOutput = HELP_MESSAGE;
        this.attributes.repromptSpeech = HELP_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.RepeatIntent': function () {
        console.log('RepeatIntent');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.StopIntent': function () {
        console.log('StopIntent');
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function () {
        console.log('CancelIntent');
        this.emit('SessionEndedRequest');
    },
    'SessionEndedRequest': function () {
        console.log('SessionEndedRequest');
        this.emit(':saveState', true);
        this.emit(':tell', STOP_MESSAGE);
    },
    'Unhandled': function () {
        console.log('Unhandled');
        if (Object.keys(this.attributes).length === 0) {
            this.emitWithState('UpdateSettings');
        } else {
            //check for real device
            let profiles = [...new Set(settings.deviceList.map(p => p.profile.toLowerCase()))];
            let realDevices = [...new Set(settings.deviceList.map(p => p.name.toLowerCase()))];
            let theCommand = this.event.request.intent.slots.ttstext.value;
            for (let [key, value] of realDevices.entries()) {
                if (theCommand.match('\\b' + value + '\\b')) {
                    console.log('realDevice ' + value);
                }
            }

            for (let [key, value] of profiles.entries()) {
                if (theCommand.match('\\b' + value + '\\b')) {
                    console.log('profile ' + value);
                }
            }

            for (let keyword in keywords) {
                if (keywords[keyword].find((it) => theCommand.includes(it))) {
                    console.log('keyword ' + keyword);
                }
            }

            for (let device in deviceTypes) {
                if (deviceTypes[device].find((it) => theCommand.includes(it))) {
                    console.log('device ' + device);
                }
            }

            this.attributes.speechOutput = HELP_MESSAGE;
            this.attributes.repromptSpeech = HELP_REPROMT;
            this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
        }
    },
};

exports.handler = function (event, context, callback) {

    //this.event.context.System.device.deviceId
    //console.log('Intent '+ event.request.intent.name);

    const alexa = Alexa.handler(event, context, callback);
    alexa.dynamoDBTableName = 'EchoSistant';
    alexa.registerHandlers(handlers);
    alexa.execute();
};