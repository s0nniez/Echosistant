/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
var alexa;
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
const showUtils = require('./alexa-sdk/lib/utils/showRenderUtils.js');

const staticResponses = require('./alexa-sdk/lib/utils/static_responses.json');
var respStrings = JSON.parse(JSON.stringify(staticResponses));

exports.handler = function(event, context, callback) {
    if (event.path === '/esData') {
        esUtils.handleDbUpdates(event.body, function(err, response) {
            callback(null, {
                statusCode: 200,
                body: JSON.stringify({
                    lambdaInfo: response
                })
            });
        });
    } else {
        //Alexa Skill call
        alexa = Alexa.handler(event, context, callback);
        alexa.dynamoDBTableName = 'EchoSistantV5';
        alexa.registerHandlers(alexaHandlers);
        alexa.execute();
    }
};

const alexaHandlers = {
    LaunchRequest: function() {
        console.error('ESLogging| LaunchRequest');
        let say = getRandomItem(respStrings.main_index.Welcome_Message).toString();
        let sayAgain = getRandomItem(respStrings.main_index.Welcome_Repromt).toString();
        this.attributes.speechOutput = say;
        this.attributes.repromptSpeech = sayAgain;
        this.response.speak(say).listen(sayAgain);
        this.emit(":responseReady");
    },
    IntentRequest: function() {
        console.log('ESLogging| IntentRequest:', this.event.request.intent.name);
        this.emit(this.event.request.intent.name);
    },
    'AMAZON.HelpIntent': function() {
        console.log('ESLogging| HelpIntent:', this.event.request.intent.name);
        let say = getRandomItem(respStrings.main_index.Help_Message).toString();
        let sayAgain = getRandomItem(respStrings.main_index.Help_Repromt).toString();
        this.attributes.speechOutput = say;
        this.attributes.repromptSpeech = sayAgain;
        this.response.speak(say).listen(sayAgain);
        this.emit(":responseReady");
    },
    'AMAZON.RepeatIntent': function() {
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },
    'AMAZON.NoIntent': function() {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.StopIntent': function() {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function() {
        this.emit('SessionEndedRequest');
    },
    SessionEndedRequest: function() {
        console.error('ESLogging| SessionEndedRequest');
        this.attributes.usingHere = undefined;
        this.attributes.configModeStage = undefined
        this.response.speak(getRandomItem(respStrings.main_index.Stop_Message).toString());
        this.emit(":responseReady");
    },
    Here: function() {
        console.error('ESLogging| Here');
        if (this.attributes.deviceProfile === undefined) {
            if (this.attributes.usingHere === undefined) {
                this.attributes.usingHere = 'FirstCall';
            }
            esUtils.handleHere.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    },
    AppStatus: function() {
        console.error("ESLogging| AppStatus");
        esUtils.appStatus.call(this);
    },
    UpdateSettings: function() {
        console.error("ESLogging| UpdateSetttings");
        if (this.attributes.configModeStage !== undefined || this.attributes.configModeStage !== "needSetValue") {
            this.attributes.configModeStage = "needSetName";
        }
        let speechOutput = "Which setting are we modifying? To list the available options, say list settings.";
        let cardTitle = "EchoSistant Settings";
        //showUtils.buildVoiceCardObject.apply(this, [speechOutput, repromptText = '', templateType, bodyTitle, bodyTextContent, askOrTell, renderCardContent = '', simpleCardTitle = '', simpleCardContent = '', listTextObj = undefined]);
        //showUtils.buildVoiceCardObject.apply(this, [speechOutput, '', "deviceCmdTemplate", cardTitle, 'Please Say a Setting Name...', ':ask']);
        this.response.speak(speechOutput).listen(speechOutput);
        this.emit(":responseReady");
    },

    Unhandled: function() {
        console.error("ESLogging| Unhandled | ttstext: (" + this.event.request.intent.slots.ttstext.value + ")");
        var self = this;
        if (this.attributes.usingHere !== undefined) {
            esUtils.handleHere.call(this);
        } else if (this.attributes.configModeStage !== undefined) {
            esUtils.handleSettings.call(this);
        } else {
            if (this.event.request.intent.slots.ttstext.value.match(/\bsend debug log\b/i)) {
                console.log('Sending Debug Log');
                esUtils.sendDebugLogs.call(this);
            } else {
                esUtils.findDevices.call(this);
            }
        }
    }
};

function getRandomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
}