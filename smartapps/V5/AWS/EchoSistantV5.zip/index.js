/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
var alexa;

const states = {
	RESPONSE: '_RESPONSE',
	STARTMODE: '_STARTMODE'
};

const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';

exports.handler = function(event, context, callback) {
	if (event.path === '/esData') {
		//API call
		esUtils.handleDbUpdates(event.body, function(err, response) {
			callback(null, {
				statusCode: 200,
				body: JSON.stringify({
					lambdaInfo: response
				})
			});
		});
	} else {
		//Alexa Skill call
		alexa = Alexa.handler(event, context, callback);
		alexa.dynamoDBTableName = 'EchoSistantV5';
		alexa.registerHandlers(newSessionHandlers, startHandlers, responseHandlers);
		alexa.execute();
	}
};

const newSessionHandlers = {
	NewSession: function() {
		this.handler.state = states.STARTMODE;
		this.emitWithState(this.event.request.intent.name);
	}
};

const startHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
	NewSession: function() {
		this.handler.state = '';
		this.emitWithState('NewSession'); // Equivalent to the Start Mode NewSession handler
	},
	LaunchRequest: function() {
		console.log('ESLogging| LaunchRequest-Start');
		//Called the Invocation word without an intent....
		this.attributes.speechOutput = WELCOME_MESSAGE;
		// If the user either does not reply to the welcome message or says something that is not
		// understood, they will be prompted again with this text.
		this.attributes.repromptSpeech = WELCOME_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	IntentRequest: function() {
		console.log('ESLogging| IntentRequest-Start', this.event.request.intent.name);
		this.emitWithState(this.event.request.intent.name);
	},
	'AMAZON.HelpIntent': function() {
		this.attributes.speechOutput = HELP_MESSAGE;
		this.attributes.repromptSpeech = HELP_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.RepeatIntent': function() {
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.StopIntent': function() {
		this.emit('SessionEndedRequest');
	},
	'AMAZON.CancelIntent': function() {
		this.emit('SessionEndedRequest');
	},
	SessionEndedRequest: function() {
		this.emit(':saveState', true);
		this.emit(':tell', STOP_MESSAGE);
	},
	Here: function() {
		var self = this;
		esUtils.handleHere(self, function(err, type, response) {
			self.emit(type, response);
		});
	},
	Unhandled: function() {
		console.error('ESLogging| Unhandled-Start');
		var self = this;
		if (this.event.request.intent.slots.ttstext.value.match(/\bsend debug log\b/i)) {
			esUtils.sendDebugLogs(self, function(err, type, response) {
				self.emit(type, response);
			});
		} else {
			esUtils.findDevices(self, function(err, type, response) {
				self.emit(type, response);
			});
		}
	}
});

const responseHandlers = Alexa.CreateStateHandler(states.RESPONSE, {
	NewSession: function() {
		this.handler.state = '';
		this.emitWithState('NewSession'); // Equivalent to the Start Mode NewSession handler
	},
	LaunchRequest: function() {
		console.error('ESLogging| LaunchRequest-Response');
		//Called the Invocation word without an intent....
		this.attributes.speechOutput = WELCOME_MESSAGE;
		// If the user either does not reply to the welcome message or says something that is not
		// understood, they will be prompted again with this text.
		this.attributes.repromptSpeech = WELCOME_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	IntentRequest: function() {
		console.log('ESLogging| IntentRequest-Response', this.event.request.intent.name);
		this.emitWithState(this.event.request.intent.name);
	},
	'AMAZON.HelpIntent': function() {
		this.attributes.speechOutput = HELP_MESSAGE;
		this.attributes.repromptSpeech = HELP_REPROMT;
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.RepeatIntent': function() {
		this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
	},
	'AMAZON.StopIntent': function() {
		this.emit('SessionEndedRequest');
	},
	'AMAZON.CancelIntent': function() {
		this.emit('SessionEndedRequest');
	},
	SessionEndedRequest: function() {
		this.emit(':saveState', true);
		this.emit(':tell', STOP_MESSAGE);
	},
	Here: function() {
		var self = this;
		esUtils.handleHere(self, function(err, type, response) {
			self.emit(type, response);
		});
	},
	Unhandled: function() {
		console.error('ESLogging| Unhandled-Response');
		var self = this;
		if (this.event.request.intent.slots.ttstext.value.match(/\bsend debug log\b/i)) {
			console.log('Sending Debug Log');
			esUtils.sendDebugLogs(self, function(err, type, response) {
				self.emit(type, response);
			});
		} else {
			esUtils.findDevices(self, function(err, type, response) {
				self.emit(type, response);
			});
		}
	}
});
