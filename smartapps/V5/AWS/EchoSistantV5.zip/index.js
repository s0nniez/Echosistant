/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('./alexa-sdk');
const startTime = process.hrtime();
var alexa;
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
// const showUtils = require('./alexa-sdk/lib/utils/showRenderUtils.js');

const staticResponses = require('./alexa-sdk/lib/utils/response_map.json');
var respStrings = JSON.parse(JSON.stringify(staticResponses));

exports.handler = function(event, context, callback) {
    if (event.path === '/esData') {
        esUtils.handleDbUpdates(event.body, function(err, response) {
            callback(null, {
                statusCode: 200,
                body: JSON.stringify({
                    lambdaInfo: response
                })
            });
        });
    } else {
        logTime(startTime, 'Alexa Skill call');
        //Alexa Skill call
        alexa = Alexa.handler(event, context, callback);
        alexa.dynamoDBTableName = 'EchoSistantV5';
        alexa.registerHandlers(alexaHandlers);
        alexa.startTime = startTime;
        alexa.execute();
        logTime(startTime, 'alexa.execute()');
    }
};

const alexaHandlers = {
    LaunchRequest: function() {
        logTime(startTime, 'LaunchRequest');
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        this.attributes.speechOutput = getSpeechItem(respStrings.Welcome, "Default", allowPersonality).toString();
        this.attributes.repromptSpeech = getSpeechItem(respStrings.Welcome, "Reprompts", allowPersonality).toString();
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },
    IntentRequest: function() {
        logTime(startTime, 'IntentRequest: ' + this.event.request.intent.name);
        this.emit(this.event.request.intent.name);
    },
    'AMAZON.HelpIntent': function() {
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        console.log('ESLogging| HelpIntent:', this.event.request.intent.name);
        this.attributes.speechOutput = getSpeechItem(respStrings.Help, "Default", allowPersonality).toString();
        this.attributes.repromptSpeech = getSpeechItem(respStrings.Help, "Reprompts", allowPersonality).toString();
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },
    'AMAZON.RepeatIntent': function() {
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },
    'AMAZON.NoIntent': function() {
        this.attributes.speechOutput = undefined;
        this.emit('SessionEndedRequest');
    },
    'AMAZON.StopIntent': function() {
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        this.attributes.speechOutput = getSpeechItem(respStrings.Stop, "Default", allowPersonality).toString();
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function() {
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        this.attributes.speechOutput = getSpeechItem(respStrings.Stop, "Default", allowPersonality).toString();
        this.emit('SessionEndedRequest');
    },
    SessionEndedRequest: function() {
        logTime(startTime, 'SessionEndedRequest');
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        this.attributes.startTime = undefined;
        this.attributes.usingHere = undefined;
        this.attributes.configModeStage = undefined;
        if (this.attributes.speechOutput) {
            this.response.speak(this.attributes.speechOutput);
        } else {
            this.attributes.speechOutput = getSpeechItem(respStrings.Stop, "Default", allowPersonality).toString();
        }
        esUtils.sendDebugLogs.call(this);
        this.emit(":responseReady");
    },

    Here: function() {
        logTime(startTime, 'Here');
        if (this.attributes.deviceProfile === undefined) {
            if (this.attributes.usingHere === undefined) {
                this.attributes.usingHere = 'FirstCall';
            }
            esUtils.handleHere.call(this);
        } else if (this.attributes.configModeStage !== undefined) {
            esUtils.handleSettings.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    },
    AppStatus: function() {
        logTime(startTime, 'AppStatus');
        esUtils.appStatus.call(this);
    },

    UpdateSettings: function() {
        logTime(startTime, 'UpdateSettings');
        let allowPersonality = (this.esData.settings.allowPersonality !== false);
        if (this.attributes.configModeStage !== undefined || this.attributes.configModeStage !== "needSetValue") {
            this.attributes.configModeStage = "needSetName";
        }
        this.attributes.speechOutput = getRandomItem(respStrings.Settings.Default).toString();
        this.attributes.repromptSpeech = getRandomItem(respStrings.Settings.Reprompts).toString();
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },

    Unhandled: function() {
        console.log(JSON.stringify(this.attributes));
        logTime(startTime, 'Unhandled');
        if (this.event.request.intent.slots.ttstext.value !== undefined) {
            console.log('Unhandled | ttstext: (' + this.event.request.intent.slots.ttstext.value + ')');
        }
        if (this.attributes.usingHere !== undefined) {
            esUtils.handleHere.call(this);
        } else if (this.attributes.configModeStage !== undefined) {
            console.log('going in');
            esUtils.handleSettings.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    }
};

function getRandomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
}

//This alternative to getRandomItem allows us to filter out the attitude responses
function getSpeechItem(itemObj, keyName, attitude) {
    let items = [];
    if (attitude !== false) {
        items = [...new Set([...itemObj[keyName], ...itemObj[keyName + "_Attitude"]])];
    } else { items = itemObj[keyName]; }
    return items[Math.floor(Math.random() * items.length)];
}

function logTime(theTime, message) {
    if (theTime !== undefined) {
        let precision = 3; // 3 decimal places
        let elapsed = process.hrtime(theTime)[1] / 1000000;
        console.log('ESLogging| ', process.hrtime(theTime)[0], 'sec, ', elapsed.toFixed(precision), 'ms - ', message);
    }
}