/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const startTime = process.hrtime();
var alexa;
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
const showUtils = require('./alexa-sdk/lib/utils/showRenderUtils.js');

const staticResponses = require('./alexa-sdk/lib/utils/static_responses.json');
var respStrings = JSON.parse(JSON.stringify(staticResponses));

exports.handler = function(event, context, callback) {
    if (event.path === '/esData') {
        esUtils.handleDbUpdates(event.body, function(err, response) {
            callback(null, {
                statusCode: 200,
                body: JSON.stringify({
                    lambdaInfo: response
                })
            });
        });
    } else {
        logTime(startTime, 'Alexa Skill call');
        //Alexa Skill call
        alexa = Alexa.handler(event, context, callback);
        alexa.dynamoDBTableName = 'EchoSistantV5';
        alexa.registerHandlers(alexaHandlers);
        alexa.startTime = startTime;
        alexa.execute();
        logTime(startTime, 'alexa.execute()');
    }
};

const alexaHandlers = {
    LaunchRequest: function() {
        logTime(startTime, 'LaunchRequest');
        let say = getRandomItem(respStrings.main_index.Welcome_Message).toString();
        let sayAgain = getRandomItem(respStrings.main_index.Welcome_Repromt).toString();
        this.attributes.speechOutput = say;
        this.attributes.repromptSpeech = sayAgain;
        this.response.speak(say).listen(sayAgain);
        this.emit(":responseReady");
    },
    IntentRequest: function() {
        logTime(startTime, 'IntentRequest: ' + this.event.request.intent.name);
        this.emit(this.event.request.intent.name);
    },
    'AMAZON.HelpIntent': function() {
        console.log('ESLogging| HelpIntent:', this.event.request.intent.name);
        let say = getRandomItem(respStrings.main_index.Help_Message).toString();
        let sayAgain = getRandomItem(respStrings.main_index.Help_Repromt).toString();
        this.attributes.speechOutput = say;
        this.attributes.repromptSpeech = sayAgain;
        this.response.speak(say).listen(sayAgain);
        this.emit(":responseReady");
    },
    'AMAZON.RepeatIntent': function() {
        this.response.speak(this.attributes.speechOutput).listen(this.attributes.repromptSpeech);
        this.emit(":responseReady");
    },
    'AMAZON.NoIntent': function() {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.StopIntent': function() {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function() {
        this.emit('SessionEndedRequest');
    },
    SessionEndedRequest: function() {
        logTime(startTime, 'SessionEndedRequest');
        this.attributes.startTime = undefined;
        this.attributes.usingHere = undefined;
        this.attributes.configModeStage = undefined;
        if (this.attributes.speechOutput) {
            this.response.speak(this.attributes.speechOutput);
        } else {
            this.response.speak(getRandomItem(respStrings.main_index.Stop_Message).toString());
        }
        esUtils.sendDebugLogs.call(this);
        this.emit(":responseReady");
    },
    Here: function() {
        logTime(startTime, 'Here');
        if (this.attributes.deviceProfile === undefined) {
            if (this.attributes.usingHere === undefined) {
                this.attributes.usingHere = 'FirstCall';
            }
            esUtils.handleHere.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    },
    AppStatus: function() {
        logTime(startTime, 'AppStatus');
        esUtils.appStatus.call(this);
    },
    UpdateSettings: function() {
        logTime(startTime, 'UpdateSettings');
        if (this.attributes.configModeStage !== undefined || this.attributes.configModeStage !== "needSetValue") {
            this.attributes.configModeStage = "needSetName";
        }
        let say = getRandomItem(respStrings.utility_stuff.Setting_Welcome).toString();
        let sayAgain = getRandomItem(respStrings.utility_stuff.Setting_Repromt).toString();
        let cardTitle = "EchoSistant Settings";
        //showUtils.buildVoiceCardObject.apply(this, [speechOutput, '', "deviceCmdTemplate", cardTitle, 'Please Say a Setting Name...', ':ask']);
        this.response.speak(say).listen(sayAgain);
        this.emit(":responseReady");
    },
    Unhandled: function() {
        console.log('this.startTime:', this.startTime);
        logTime(startTime, 'Unhandled | ttstext: (' + this.event.request.intent.slots.ttstext.value + ')');
        if (this.attributes.usingHere !== undefined) {
            esUtils.handleHere.call(this);
        } else if (this.attributes.configModeStage !== undefined) {
            esUtils.handleSettings.call(this);
        } else {
            esUtils.findDevices.call(this);
        }
    }
};

function getRandomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
}

function logTime(theTime, message) {
    if (theTime !== undefined) {
        let precision = 3; // 3 decimal places
        let elapsed = process.hrtime(theTime)[1] / 1000000;
        console.log('ESLogging| ', process.hrtime(theTime)[0], ' s, ', elapsed.toFixed(precision), ' ms - ', message);
    }
}
