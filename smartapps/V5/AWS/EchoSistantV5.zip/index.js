/**
 *  EchoSistant - Lambda Code
 *
 *  Complete Overhaul using the Alexa-SDK!
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const esUtils = require('./alexa-sdk/lib/utils/esUtils.js');
var alexa;

const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';

var cardTitle = 'EchoSistant Evolution';
var cardContent = '';

var appLogo = {
	smallImageUrl: 'https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png',
	largeImageUrl: 'https://raw.githubusercontent.com/tonesto7/app-icons/master/Echosistant_V5.png'
};

exports.handler = function(event, context, callback) {
	if (event.path === '/esData') {
		esUtils.handleDbUpdates(event.body, function(err, response) {
			callback(null, {
				statusCode: 200,
				body: JSON.stringify({
					lambdaInfo: response
				})
			});
		});
	} else {
		//Alexa Skill call
		alexa = Alexa.handler(event, context, callback);
		alexa.dynamoDBTableName = 'EchoSistantV5';
		alexa.registerHandlers(alexaHandlers);
		alexa.execute();
	}
};

const alexaHandlers = {
	NewSession: function() {
		console.error('ESLogging| NewSession');
		this.attributes.startSession = true;
		this.emit(this.event.request.intent.name);
	},
	LaunchRequest: function() {
		console.error('ESLogging| LaunchRequest ', this.attributes.startSession);
		this.attributes.speechOutput = WELCOME_MESSAGE;
		this.attributes.repromptSpeech = WELCOME_REPROMT;
		this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
	},
	IntentRequest: function() {
		console.log('ESLogging| IntentRequest ', this.attributes.startSession, ' Intent:', this.event.request.intent.name);
		this.emit(this.event.request.intent.name);
	},
	'AMAZON.HelpIntent': function() {
		this.attributes.speechOutput = HELP_MESSAGE;
		this.attributes.repromptSpeech = HELP_REPROMT;
		this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
	},
	'AMAZON.RepeatIntent': function() {
		this.emit(':askWithCard', this.attributes.speechOutput, this.attributes.repromptSpeech, cardTitle, this.attributes.speechOutput, appLogo);
	},
	'AMAZON.StopIntent': function() {
		this.emit('SessionEndedRequest');
	},
	'AMAZON.CancelIntent': function() {
		this.emit('SessionEndedRequest');
	},
	SessionEndedRequest: function() {
		console.error('ESLogging| SessionEndedRequest');
		this.attributes.startSession = false;
		this.emit(':saveState', true);
		this.emit(':tellWithCard', STOP_MESSAGE, cardTitle, STOP_MESSAGE, appLogo);
	},
	Here: function() {
		console.error('ESLogging| Here');
		var self = this;
		esUtils.handleHere(self, function(err, type, response) {
			self.emit(type, response)//;, cardTitle, response, appLogo);
		});
	},
	'UpdateSettings': function() {

	},
	Unhandled: function() {
		console.error('ESLogging| Unhandled ', this.attributes.startSession);
		var self = this;
		if (this.event.request.intent.slots.ttstext.value.match(/\bsend debug log\b/i)) {
			console.log('Sending Debug Log');
			esUtils.sendDebugLogs(self, function(err, type, response) {
				self.emit(type, response, cardTitle, response, appLogo);
			});
		} else {
			esUtils.findDevices(self, function(err, type, response) {
				self.emit(type, response, cardTitle, response, appLogo);
			});
		}
	}
};
