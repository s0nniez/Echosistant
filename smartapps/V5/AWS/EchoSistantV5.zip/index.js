/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.4.00 - 6/30/2017 Complete overhaul!
 *  Version 5.3.00 - 6/21/2017 Added US Skill
 *  Version 5.1.00 - 3/21/2017 Added Reminders Profile
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const https = require('https');
const STtoken = process.env.STtoken;
const STurl = process.env.STurl;
const versionTxt = '5.4';

//will eventually be a var...
var keywords = {
    'feedback': ['give', 'for', 'tell', 'what', 'how', 'is', 'when', 'which', 'are', 'how many', 'check', 'who', 'status'],
    'enable': ['on', 'start', 'enable', 'engage', 'open', 'begin', 'unlock', 'unlocked'],
    'disable': ['off', 'stop', 'cancel', 'disable', 'disengage', 'kill', 'close', 'silence', 'lock', 'locked', 'quit', 'end'],
    'more': ['increase', 'more', 'too dark', 'not bright enough', 'brighten', 'brighter', 'turn up'],
    'less': ['darker', 'too bright', 'dim', 'dimmer', 'decrease', 'lower', 'low', 'softer', 'less'],
    'delay': ['delay', 'wait', 'until', 'after', 'around', 'within', 'in', 'about']
};

//will eventually be a var...
var deviceTypes = [
    'light', 'switch', 'fan', 'lock', 'garage', 'door', 'window', 'shade', 'curtain', 'blind', 'tstat', 'indoor', 'outdoor', 'vent', 'valve', 'water', 'speaker', 'synth', 'media', 'relay'
];

/*
for (var keyword in keywords) {
    if (keywords[keyword].find((it) => theCommand.includes(it))) {
        console.log(keyword);
    }
}
*/

const SKILL_NAME = 'EchoSistant';
const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const REPROMPT_SPEECH = 'Anything else?';
const EXIT_SKILL_MESSAGE = 'Goodbye';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';
const SETTINGS_UPDATED = 'I have updated your settings.';
const ERROR = 'Something went wrong';


const handlers = {
    'NewSession': function () {
        console.log('NewSession');
        if (Object.keys(this.attributes).length === 0) {
            //First time user has called so we need to update settings
            this.emitWithState('UpdateSettings');
        } else {
            //Settings have already been setup, so we call the request type
            this.emitWithState(this.event.request.type);
        }
    },
    'LaunchRequest': function () {
        console.log('LaunchRequest');
        //Called the Invocation word without an intent....


        this.attributes.speechOutput = WELCOME_MESSAGE;
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = WELCOME_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'IntentRequest': function () {
        console.log('IntentRequest');
        //Called the invocation word with an intent...
        // this.event.request.intent.name = the profile name

        this.attributes.speechOutput = WELCOME_MESSAGE;
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = WELCOME_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'UpdateSettings': function () {
        console.log('UpdateSettings');
        var beginURL = STurl + 'update?access_token=' + STtoken;
        var self = this;
        https.get(beginURL, function (res) {
            console.error("Got response: " + res.statusCode);
            res.on("data", function (data) {
                var getJSON = JSON.parse(data);
                self.attributes.allESSettings = getJSON.data;
                if (self.event.request.intent.name == 'UpdateSettings') {
                    self.emit(':tell', self.t('SETTINGS_UPDATED'));
                } else {
                    self.emitWithState(self.event.request.type);
                }
            });
        }).on('error', function (e) {
            console.error("Got error: " + e.message);
            self.emit(':tell', self.t('ERROR'));
        });
    },
    'AMAZON.HelpIntent': function () {
        console.log('HelpIntent');
        this.attributes.speechOutput = HELP_MESSAGE;
        this.attributes.repromptSpeech = HELP_REPROMT;
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.RepeatIntent': function () {
        console.log('RepeatIntent');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.StopIntent': function () {
        console.log('StopIntent');
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function () {
        console.log('CancelIntent');
        this.emit('SessionEndedRequest');
    },
    'SessionEndedRequest': function () {
        console.log('SessionEndedRequest');
        this.emit(':saveState', true);
        this.emit(':tell', STOP_MESSAGE);
    },
    'Unhandled': function () {
        console.log('Unhandled');
        if (Object.keys(this.attributes).length === 0) {
            this.emitWithState('UpdateSettings');
        } else {
            this.attributes.speechOutput = HELP_MESSAGE;
            this.attributes.repromptSpeech = HELP_REPROMPT;
            this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
        }
    },
};

exports.handler = function (event, context, callback) {

    //this.event.context.System.device.deviceId
    //console.log('Intent '+ event.request.intent.name);

    const alexa = Alexa.handler(event, context, callback);
    //alexa.APP_ID = '';
    alexa.dynamoDBTableName = 'EchoSistant';

    alexa.registerHandlers(handlers);
    alexa.execute();
};