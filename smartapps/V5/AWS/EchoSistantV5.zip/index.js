/**
 *  EchoSistant - Lambda Code
 *
 *  Version 5.0.00 - 8/02/2017 Complete Overhaul using the Alexa-SDK!
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
'use strict';
const Alexa = require('alexa-sdk');
const https = require('https');
const stHost = process.env.stHost.split(':')[0];
const stPort = process.env.stHost.split(':')[1];
const stPath = process.env.stPath;

const commandKeywords = {
  feedback: ['give', 'for', 'tell', 'what', 'how', 'is', 'when', 'which', 'are', 'how many', 'check', 'who', 'status'],
  on: ['on', 'start', 'enable', 'engage', 'open', 'begin'],
  lock: ['lock', 'locked', 'locking'],
  off: ['off', 'stop', 'cancel', 'disable', 'disengage', 'kill', 'close', 'silence', 'quit', 'end'],
  unlock: ['unlock', 'unlocked', 'unlocking'],
  more: ['increase', 'more', 'too dark', 'not bright enough', 'brighten', 'brighter', 'turn up'],
  less: ['darker', 'too bright', 'dim', 'dimmer', 'decrease', 'lower', 'low', 'softer', 'less'],
  delay: ['delay', 'wait', 'until', 'after', 'around', 'within', 'about', 'for'] //TODO need to add the word 'in' and these keywords require a value
};

//TODO update this list based on testing
const deviceAttributes = {
  switch: ['light', 'switch', 'fan', 'outlet', 'relay'],
  lock: ['lock'],
  door: ['door', 'garage'], //'window', 'shade', 'curtain', 'blind', 'tstat', 'indoor', 'outdoor', 'vent', 'valve', 'water', 'speaker', 'synth', 'media', 'relay'
  contact: ['window', 'door', 'window']
};

const SKILL_NAME = 'EchoSistant';
const WELCOME_MESSAGE = 'Yes';
const WELCOME_REPROMT = 'Welcome reprompt';
const REPROMPT_SPEECH = 'Anything else?';
const EXIT_SKILL_MESSAGE = 'Goodbye';
const HELP_MESSAGE = 'Examples of things to say';
const HELP_REPROMT = 'Need more Help?';
const STOP_MESSAGE = 'I am here if you need me';
const SETTINGS_UPDATED = 'I have updated your settings.';
const ERROR = 'Something went wrong';

exports.handler = function (event, context, callback) {
  
  const alexa = Alexa.handler(event, context, callback);
  alexa.dynamoDBTableName = 'EchoSistantV5';
  alexa.registerHandlers(handlers);
  alexa.execute();
};

function callST(bodyData, callback) {
  var options;
  if (bodyData !== '') {
    var postHeaders = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(bodyData, 'utf8')
    };
    options = {
      host: stHost,
      path: stPath,
      port: stPort,
      method: 'POST',
      headers: postHeaders
    };
  } else {
    options = {
      host: stHost,
      path: stPath,
      port: stPort,
      method: 'GET'
    };
  }
  var req = https.request(options, res => {
    res.setEncoding('utf-8');
    var result = '';
    res.on('data', data => {
      result += data;
    });
    res.on('end', function () {
      callback(result);
    });
  });
  req.write(bodyData);
  req.end();
  req.on('error', e => {
    console.error('HTTP error: ' + e.message);
  });
}

const handlers = {
  NewSession: function () {
    console.log('NewSession');
    if (Object.keys(this.attributes).length === 0) {
      //First time user has called so we need to update settings
      this.emitWithState('UpdateSettings');
    } else {
      //Settings have already been setup, so we call the request type
      this.emitWithState(this.event.request.type);
    }
  },
  LaunchRequest: function () {
    console.log('LaunchRequest');
    //Called the Invocation word without an intent....

    this.attributes.speechOutput = WELCOME_MESSAGE;
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    this.attributes.repromptSpeech = WELCOME_REPROMT;
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  IntentRequest: function () {
    console.log('IntentRequest');
    //Called the invocation word with an intent...
    // this.event.request.intent.name = the profile name

    this.emitWithState(this.event.request.intent.name);

    //this.attributes.speechOutput = WELCOME_MESSAGE;
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    //this.attributes.repromptSpeech = WELCOME_REPROMT;
    //this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  UpdateSettings: function () {
    var self = this;
    callST('', function (response) {
      self.attributes.devices = JSON.parse(response).data;
      if (self.event.request.intent.name == 'UpdateSettings') {
        self.emit(':tell', SETTINGS_UPDATED);
      } else {
        self.emitWithState(self.event.request.type);
      }
    });
  },
  'AMAZON.HelpIntent': function () {
    console.log('HelpIntent');
    this.attributes.speechOutput = HELP_MESSAGE;
    this.attributes.repromptSpeech = HELP_REPROMT;
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  'AMAZON.RepeatIntent': function () {
    console.log('RepeatIntent');
    this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
  },
  'AMAZON.StopIntent': function () {
    console.log('StopIntent');
    this.emit('SessionEndedRequest');
  },
  'AMAZON.CancelIntent': function () {
    console.log('CancelIntent');
    this.emit('SessionEndedRequest');
  },
  SessionEndedRequest: function () {
    console.log('SessionEndedRequest');
    this.emit(':saveState', true);
    this.emit(':tell', STOP_MESSAGE);
  },
  Unhandled: function () {
    console.log('Unhandled');
    if (Object.keys(this.attributes).length === 0) {
      this.emitWithState('UpdateSettings');
    } else {
      let devices = this.attributes.devices;
      let deviceNames = devices.map(d => d.label);
      let roomNames = [...new Set(devices.map(r => r.rooms).reduce((a, b) => a.concat(b)))];
      let theRoom = this.event.request.intent.name;
      let theCommand = this.event.request.intent.slots.Text.value.toLowerCase();
      let theDevices = [];
      let theDevice = '';
      let theActions = [];

      //Search for keywords
      for (let keyword in commandKeywords) {
        if (commandKeywords[keyword].find(it => theCommand.includes(it))) {
          theActions.push(keyword);
        }
      }

      //Search for individual devices
      for (let [device, deviceName] of deviceNames.entries()) {
        findMatch(theCommand, '\\b' + deviceName.toLowerCase() + '\\b', function (result) {
          if (result) {
            if (deviceName.length > theDevice.length) {
              for (let theAction of theActions) {
                findMatch(devices[device].commands, '\\b' + theAction + '(?:es|s)?\\b', function (result) {
                  if (result) {
                    theDevice = deviceName;
                    theDevices = [devices[device].id];
                    theActions = [theAction];
                  }
                });
              }
            }
          }
        });
      }

      // If they spoke of an individual device then we ignore everything else and just work with that device alone otherwise keep parsing
      if (theDevices.length === 0) {
        //Tweak this section to see if they mentioned a room name. Figure out which one takes priority, the invocation word or the word spoken.
        //Might need to find multiple rooms in the future....
        for (let [room, roomName] of roomNames.entries()) {
          findMatch(theCommand, "\\b" + roomName.toLowerCase() + '\\b', function (result) {
            if (result) {
              theRoom = roomName;
            }
          });
        }

        //Find all devices in the room that have the keyword action (on, off, etc)
        for (let deviceType in deviceAttributes) {
          if (deviceAttributes[deviceType].find(it => theCommand.includes(it))) {
            theDevices = theDevices.concat(devices.filter(room => room.rooms.toString().toLowerCase().includes(theRoom.toLowerCase())).filter(attribute => attribute.attributes.includes(deviceType)).map(d => d.id));
          }
        }
      }

      let processData = JSON.stringify({
        theRoom: theRoom,
        theActions: theActions,
        theDevices: theDevices,
        theDelay: 0,
        deviceId: this.event.context.System.device.deviceId,
        requestId: this.event.request.requestId,
        sessionId: this.event.session.sessionId
      });

      var self = this;
      callST(processData, function (response) {
        //depending on response, have alexa respond accordingly
        self.emit(':tell', 'ok');
      });
    }
  }
};

function findMatch(searchIn, theMatch, callBack) {
  let results;
  let regEx = new RegExp(theMatch);
  if (typeof searchIn == 'object') {
    for (let item of searchIn) {
      if (regEx.test(item)) {
        results = item;
      }
    }
  } else {
    if (regEx.test(searchIn)) {
      results = true;
    }
  }
  callBack(results);
}