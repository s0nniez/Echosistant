'use strict';

function cleanString(str) {
	return str.replace(/[^A-Za-z0-9 ]/gi, '').toLowerCase(); // Better regex... the other one was missing some things...
}

const theCommand = cleanString('turn off the lights');
const theIntent = 'Office';
let theParsedCommand = theCommand;

let theItemsFound = [];
// Data from the dynamobd
const devData = require('./devData.json');
const roomNames = [...new Set(devData.map((r) => r.rooms).reduce((a, b) => a.concat(b)))].map((a) => Object.assign({theId: a, theType: 'room', toFind: cleanString(a)}));

let devicesToSearchFor = [];
let deviceCapToSearchFor = [];
let cmdToSearchFor = [];

devData.forEach((device) => {
	devicesToSearchFor.push({ theId: device.deviceId, theType: 'device', toFind: cleanString(device.label) }); // real device name
	device.capabilities.forEach((cap) => {
		deviceCapToSearchFor.push({ theId: device.deviceId, theType: 'deviceType', toFind: cleanString(cap) }); // filter for deviceTypes
	});
	device.commands.forEach((command) => {
	let splitCmd = command.replace(/:.*/, '').split(/(?=[A-Z]+[^A-Z]?)/);
		if (splitCmd.length > 1) {
			splitCmd = splitCmd.join(' ');
		} 
		cmdToSearchFor.push({ theId: device.deviceId, theType: 'command', toFind: cleanString(splitCmd.toString()) }); // filter commands
	});
});

// Add the intent room if its a real room and not already in the command
if (!theCommand.includes(cleanString(theIntent))) {
	if (roomNames.some(r => r.toFind.includes(cleanString(theIntent)))) {
		theParsedCommand += ' ' + cleanString(theIntent) // Add the intent room if its a real room and not already in the command
	}
}

// This collects the data we just created and concats the 3 objects together, keeping the same format and sorting them from largest to smallest
const itemsToParse = [].concat(devicesToSearchFor, cmdToSearchFor, deviceCapToSearchFor, roomNames).sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));

for (let itemToFind of itemsToParse) {
	if (theParsedCommand.match('\\b' + itemToFind.toFind + 's?\\b')) {
		//theParsedCommand = theParsedCommand.replace(foundWord.toFind, '').trim();
		theItemsFound.push({ theItemFound: itemToFind, theLocation: theCommand.indexOf(itemToFind.toFind) }); // Finds every possible keyword in the command
	}
}

// Turn all found items into device IDs
const theFoundDevices = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'device').map((theItems) => theItems.theItemFound.theId);
const theFoundCmds = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'command').map((theItems) => theItems.theItemFound.theId);
const theFoundDeviceTypes = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'deviceType').map((theItems) => theItems.theItemFound.theId);
const theFoundRooms = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'room').map((theItems) => theItems.theItemFound.theId);

// Filter found devices by found commands
const foundRealDeviceAndCmd = theFoundDevices.filter((foundDevice) => theFoundCmds.includes(foundDevice));
const foundDeviceTypeAndCmd = theFoundDeviceTypes.filter((foundDevice) => theFoundCmds.includes(foundDevice));

if (foundRealDeviceAndCmd.length) {
	console.log('Found Real Deivice ', foundRealDeviceAndCmd); // REAL DEVICE WITH PROPER CMD FOUND!
} else if (foundDeviceTypeAndCmd.length) {
	console.log('DeviceTypes found with command ', foundDeviceTypeAndCmd); // FOUND POSSIBLE DEVICE WITH PROPER CMD!
}

// Filter all deivces with proper commands that are in found room
const itemsToFindInRooms = [...new Set([].concat(foundRealDeviceAndCmd, foundDeviceTypeAndCmd, theFoundDeviceTypes))];
const devicesInRooms = devData.filter((device) => itemsToFindInRooms.includes(device.deviceId));

let foundDevicesWithCmdInRoom = []
devicesInRooms.forEach((device) => {
	if (itemsToFindInRooms.includes(device.deviceId)) {
		device.rooms.forEach((theRoom) => {
			if (theFoundRooms.includes(theRoom)) {
				foundDevicesWithCmdInRoom.push(device.deviceId);
			}
		});
	}
});


if (foundDevicesWithCmdInRoom.length) {
	// NEED TO ADD CMDS BACK TO THESE DEVICES theFoundCmds
	console.log('Found Device and/or DeviceType with Proper CMD and in the Correct Room ', foundDevicesWithCmdInRoom);
}


/*
cmdToSearchFor.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));
let actionsFound = [];
for (let foundWord of cmdToSearchFor) {
	if (theParsedCommand.match('\\b' + foundWord.toFind + '\\b')) {
		//theParsedCommand = theParsedCommand.replace(foundWord.toFind, '').trim();
		actionsFound.push({ theItemFound: foundWord, theLocation: theCommand.indexOf(foundWord.toFind) });
	}
}


//console.log(actionsFound);

deviceCapToSearchFor.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));
let deviceTypesFound = [];
for (let foundWord of deviceCapToSearchFor) {
	if (theParsedCommand.match('\\b' + foundWord.toFind + 's?\\b')) {
		//theParsedCommand = theParsedCommand.replace(foundWord.toFind, '').trim();
		deviceTypesFound.push({ theItemFound: foundWord, theLocation: theCommand.indexOf(foundWord.toFind) });
	}
}

//console.log(deviceTypesFound);

roomNames.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));
let roomsFound = [];
for (let foundWord of roomNames) {
	if (theParsedCommand.match('\\b' + foundWord.toFind + '\\b')) {
		//theParsedCommand = theParsedCommand.replace(foundWord.toFind, '').trim();
		roomsFound.push({ theItemFound: foundWord, theLocation: theCommand.indexOf(foundWord.toFind) });
	}
}

/console.log(roomsFound);


/*
//console.log(actionsFound);
//console.log(devicesFound);
//console.log(deviceTypesFound);
//console.log(roomsFound);




// This collects the data we just created and concats the 3 objects together, keeping the same format and sorting them from largest to smallest
const validWords = [].concat(roomNames, deviceNames, attrToSearchFor).sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind));

// This loops through the command from alexa and pulls out any words found, but also keeps track of the words location so we can put it back together in order
for (let validWord of validWords) {
	if (theParsedCommand.match('\\b' + validWord.toFind + '\\b')) {
		theParsedCommand = theParsedCommand.replace(validWord.toFind, '').trim();
		theItemsFound.push({ theItemFound: validWord, theOrder: theCommand.indexOf(validWord.toFind)});
	}
}
// Re-order the words found so we can put the correct action or room with the correct device
theItemsFound.sort((a, b) => a.theOrder - b.theOrder);

// Filter out add or remove devices based on commands, rooms, and actions
const theFoundDevices = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'device').map((theItems) => theItems.theItemFound.theId);
const theFoundRooms = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'room').map((theItems) => theItems.theItemFound.theId);
const theFoundDeviceTypes = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'deviceType').map((theItems) => theItems.theItemFound.theId);
const theFoundActions = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'action').map((theItems) => theItems.theItemFound.theId);
//const theFoundCaps = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'capabilities').map((theItems) => theItems.theItemFound.theId)

let matchedFoundDevicesToRoomsAndActions = [];

const theRoomsDevices = devData.map((theItem) => Object.assign({ deviceId: theItem.deviceId, theRooms: theItem.rooms }))
for (let theRoom of theFoundRooms) {
	matchedFoundDevicesToRoomsAndActions = matchedFoundDevicesToRoomsAndActions.concat(theRoomsDevices.filter((theItem) => theItem.theRooms == theRoom).map((theItem) => theItem.deviceId));
}

// Find all capabilities in the deviceTypes found
const theCapDevices = devData.map((theItem) => Object.assign({deviceId: theItem.deviceId, theCaps: theItem.capabilities}));
for (let theCap of theFoundDeviceTypes) {
	matchedFoundDevicesToRoomsAndActions = matchedFoundDevicesToRoomsAndActions.concat(theCapDevices.filter((theItem) => theItem.theCaps == theCap).map((theItem) => theItem.deviceId));
}

// Find all the devices in the commands found
const theCmdDevices = devData.map((theItem) => Object.assign({deviceId: theItem.deviceId, theCmds: theItem.commands}));
for (let theCmd of theFoundActions) {
	matchedFoundDevicesToRoomsAndActions = matchedFoundDevicesToRoomsAndActions.concat(theCmdDevices.filter((theItem) => theItem.theCmds == theCmd).map((theItem) => theItem.deviceId));
}

console.log('Items found in the command: ', theItemsFound);
console.log('The rooms found in the command and/or intent ', theFoundRooms);
console.log('The action words found in the command ', theFoundActions);
console.log('The devices found in the command ', theFoundDevices);
console.log('The devices found in the room and command based on the actions found ', matchedFoundDevicesToRoomsAndActions);
//console.log(theFoundCaps);
*/
