/*jshint esversion: 6 */
"use strict";

//Loads the FuseJS module
// const Fuse = require('./fuse.js');
// Load the string_score plugin https://github.com/joshaven/string_score
//require("string_score");

function cleanString(str) {
    return str.replace(/[^A-Za-z0-9 ]/gi, '').toLowerCase(); // Better regex... the other one was missing some things...
}

//This checks that a command string was sent as a parameter
if(!process.argv[2]) { console.log("Missing Intent Parameter!!!"); return ;}
if(!process.argv[3]) { console.log("PARAMETER ERROR: Search String not found!!!"); console.log("Please add a command to test:"); console.log("Example: test-tony.js 'house' 'turn off the kitchen light'"); return ;}


//These are the global variables for this script.
const theIntent = cleanString(process.argv[2]);
const theCommand = cleanString(process.argv[3]);

let theParsedCommand = theCommand;
let theItemsFound = [];

//This switches the dataSrc used between mine and coreys
const devData = require("./devData-tony.json");
const parseData = require('./parseData.json');
const roomNames = [...new Set(devData.map((r) => r.rooms).reduce((a, b) => a.concat(b)))].map((a) => Object.assign({theId: a, theType: 'room', theName: cleanString(a)}));
const deviceNames = devData.map((device) => Object.assign({ theId: device.deviceId, theType: 'device', theName: cleanString(device.label) }));

let attrToSearchFor = [];
parseData.forEach((deviceTypes) => {
	deviceTypes.capabilities.forEach((device) => {
		attrToSearchFor.push({theId: deviceTypes.deviceType, theType: 'capabilities', theName: cleanString(device)}); // filter for caps? 
	});
	deviceTypes.deviceNames.forEach((device) => {
		attrToSearchFor.push({theId: deviceTypes.deviceType, theType: 'deviceType', theName: cleanString(device)}); // filter for deviceTypes
	});
	deviceTypes.commands.forEach((command) => {
		command.words.forEach((word) => {
			attrToSearchFor.push({theId: command.action, theType: 'action', theName: cleanString(word)}); // filter for actions
		});
	});
});

// This collects the data we just created and concats the 3 objects together, keeping the same format and sorting them from largest to smallest
const validWords = [].concat(roomNames, deviceNames, attrToSearchFor).sort((a, b) => b.theName.length - a.theName.length || a.theName.localeCompare(b.theName));

// This loops through the command from alexa and pulls out any words found, but also keeps track of the words location so we can put it back together in order
for (let validWord of validWords) {
	if (theParsedCommand.match('\\b' + validWord.theName + '\\b')) {
		theParsedCommand = theParsedCommand.replace(validWord.theName, '').trim();
		theItemsFound.push({theItemFound: validWord, theOrder: theCommand.indexOf(validWord.theName)});
	}
}
// Re-order the words found so we can put the correct action or room with the correct device
theItemsFound.sort((a, b) => a.theOrder - b.theOrder);

// Filter out add or remove devices based on commands, rooms, and actions
let theFoundDevices = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'device').map((theItems) => theItems.theItemFound.theId);
let theFoundRooms = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'room').map((theItems) => theItems.theItemFound.theId);
const theFoundDeviceTypes = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'deviceType').map((theItems) => theItems.theItemFound.theId);
const theFoundActions = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'action').map((theItems) => theItems.theItemFound.theId);
const theFoundCaps = theItemsFound.filter((theItems) => theItems.theItemFound.theType === 'capabilities').map((theItems) => theItems.theItemFound.theId);

// Find all devices in the rooms found
// Check to see if the Intent is a real room, and add it to the list if not found yet, so we can get those devices.
if (roomNames.some(r => r.theName.includes(cleanString(theIntent)))) {
	if (!theFoundRooms.some(r => cleanString(r).includes(theIntent))) {
		theFoundRooms.push(theIntent); //add room if needed
	}
}
const theRoomsDevices = devData.map((theItem) => Object.assign({ deviceId: theItem.deviceId, theRooms: theItem.rooms }))
for (let theRoom of theFoundRooms) {
	theFoundDevices = theFoundDevices.concat(theRoomsDevices.filter((theItem) => theItem.theRooms == theRoom).map((theItem) => theItem.deviceId));
}

// Find all capabilities in the deviceTypes found
const theCapDevices = devData.map((theItem) => Object.assign({deviceId: theItem.deviceId, theCaps: theItem.capabilities}));
for (let theCap of theFoundDeviceTypes) {
	theFoundDevices = theFoundDevices.concat(theCapDevices.filter((theItem) => theItem.theCaps == theCap).map((theItem) => theItem.deviceId));
}

// Find all the devices in the commands found
const theCmdDevices = devData.map((theItem) => Object.assign({deviceId: theItem.deviceId, theCmds: theItem.commands}));
for (let theCmd of theFoundActions) {
	theFoundDevices = theFoundDevices.concat(theCmdDevices.filter((theItem) => theItem.theCmds == theCmd).map((theItem) => theItem.deviceId));
}

console.log(theItemsFound);
console.log(theFoundRooms);
console.log(theFoundActions);
console.log(theFoundDevices);
console.log(theFoundCaps);
