'use strict';

const theCommand = 'turn on the subwoofer and set away'; //cleanString(alexaData.event.request.intent.slots.ttstext.value);
const theIntent = 'house'; //alexaData.event.request.intent.name;
let theParsedCommand = theCommand;

let devicesToSearchFor = [];
let roomsToSearchFor = [];
let deviceTypeToSearchFor = [];
let cmdToSearchFor = [];
// Data from the dynamobd
const devData = require('./devData.json'); //alexaData.esData.devData;
const locData = require('./locData.json'); //alexaData.esData.locData;

const modesToSearchFor = locData.availStModes.map((mode) => Object.assign({
    theId: mode.id,
    theType: 'mode',
    toFind: cleanString(mode.name),
    modeName: cleanString(mode.name)
}));
const allRoomNames = [...new Set(devData.map((r) => r.rooms).reduce((a, b) => a.concat(b)))].map((a) => Object.assign({
    theId: a,
    theType: 'room',
    toFind: cleanString(a)
}));

devData.forEach((device) => {
    devicesToSearchFor.push({
        theId: device.deviceId,
        theType: 'device',
        toFind: cleanString(device.label),
        devName: cleanString(device.label)
    }); // real device name
    device.rooms.forEach((room) => {
        roomsToSearchFor.push({
            theId: device.deviceId,
            theType: 'room',
            toFind: cleanString(room),
            devName: cleanString(device.label)
        }); // filter for deviceTypes
    });
    device.capabilities.forEach((cap) => {
        deviceTypeToSearchFor.push({
            theId: device.deviceId,
            theType: 'deviceType',
            toFind: cleanString(cap),
            devName: cleanString(device.label)
        }); // filter for deviceTypes
    });
    device.commands.forEach((command) => {
        let splitCmd = command.replace(/:.*/, '').split(/(?=[A-Z]+[^A-Z]?)/);
        if (splitCmd.length > 1) {
            splitCmd = splitCmd.join(' ');
        }
        cmdToSearchFor.push({
            theId: device.deviceId,
            theType: 'action',
            toFind: cleanString(splitCmd.toString()),
            devName: cleanString(device.label)
        }); // filter commands
    });
});

// Add the intent room if its a real room and not already in the command
if (!theCommand.includes(cleanString(theIntent))) {
    if (allRoomNames.some((r) => r.toFind.includes(cleanString(theIntent)))) {
        theParsedCommand += ' ' + cleanString(theIntent); // Add the intent room if its a real room and not already in the command
    }
}

function parseFor(itemsToParse) {
    let theItemsFound = [];
    for (let itemToFind of itemsToParse) {
        if (theParsedCommand.match('\\b' + itemToFind.toFind + 's?\\b')) {
            theItemsFound.push({
                theId: itemToFind.theId,
                theName: itemToFind.devName,
                theLocation: theParsedCommand.indexOf(itemToFind.toFind),
                theType: itemToFind.theType,
                toFind: itemToFind.toFind
            });
            //theItemsFound.push({ theItemFound: itemToFind, theLocation: theParsedCommand.indexOf(itemToFind.toFind) }); // Finds every possible keyword in the command
            //theItemsFound.push({ theItemFound: itemToFind, theLocation: theLocation });
        }
    }

    return theItemsFound.sort((a, b) => a.theLocation - b.theLocation);

    /*
    let theNewLocation = -1;
    let thePrevLocation = 0;
    var reSort = theItemsFound.reduce((acc, curr) => {
    	if (curr.theLocation !== thePrevLocation) {
    		theNewLocation += 1;
    	}
    	thePrevLocation = curr.theLocation;
    	curr.theLocation = theNewLocation;
    	return acc.concat(curr);
    }, []);
    return reSort;
    */
}

// This collects the data we just created and concats the 3 objects together, keeping the same format and sorting them from largest to smallest
//const itemsToParse = [].concat(devicesToSearchFor, cmdToSearchFor, deviceTypeToSearchFor, roomsToSearchFor, modesToSearchFor);

const theFoundDevices = parseFor(devicesToSearchFor); //.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind)));
const theFoundModes = parseFor(modesToSearchFor); //.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind)));
const theFoundRooms = parseFor(roomsToSearchFor); //.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind)));
const theFoundActions = parseFor(cmdToSearchFor); //.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind)));
const theFoundDeviceTypes = parseFor(deviceTypeToSearchFor); //.sort((a, b) => b.toFind.length - a.toFind.length || a.toFind.localeCompare(b.toFind)));

let modeCmd = null;
let shmCmd = null;
let appCmds = [];
let devCmds = {};

function processResults() {
    let actionFilter = [];
    let roomOrDevTypeFound = false;
    if (theFoundModes.length) {
        modeCmd = theFoundModes.map((theMode) => theMode.theId);
    }

    // This line below was replaced with the new getItems() function...
    //let byRoomByDevType = theFoundDeviceTypes.filter((theItem) => theFoundRooms.map((roomItem) => roomItem.theId).includes(theItem.theId) && theFoundRooms.map((roomItem) => roomItem.theLocation).includes(theItem.theLocation));
    let byRoomByDevType = []
    theFoundRooms.forEach((theItem) => {
        let theFoundItem = getItems(theFoundDeviceTypes, theFoundRooms, theItem.theId, theItem.theLocation);
        if (theFoundItem.length) {
            byRoomByDevType.push(theItem);
        }
    });

    // This area still needs testing...
    if (byRoomByDevType.length) {
        actionFilter = byRoomByDevType;
        roomOrDevTypeFound = true;
    } else if (theFoundDeviceTypes.length) {
        actionFilter = theFoundDeviceTypes;
        roomOrDevTypeFound = true;
    } else {
        actionFilter = theFoundActions;
    }

    // This area still needs testing...
    if (theFoundDevices.length) {
        if (roomOrDevTypeFound) {
            actionFilter = actionFilter.concat(theFoundDevices);
        } else {
            actionFilter = theFoundDevices;
        }
    }

    let byActions = [];
    actionFilter.forEach((theItem) => {
        let theFoundAction = getItems(theFoundActions, actionFilter, theItem.theId, theItem.theLocation).map((theAction) => theAction.toFind); // Return the action value based on the theId and theLocation
        if (theFoundAction) {
            byActions.push({
                theId: theItem.theId,
                theName: theItem.theName,
                theLocation: theItem.theLocation,
                theType: theItem.theType,
                toFind: theItem.toFind,
                theAction: theFoundAction
            });
        }
    });

    byActions.sort((a, b) => a.theAction - b.theAction);
    devCmds = byActions.reduce((acc, curr) => {
        acc[curr.theAction] = acc[curr.theAction] || [];
        acc[curr.theAction].push(curr.theId);
        return acc;
    }, {});
}

processResults();

let processData = JSON.stringify({
    theRoom: theIntent,
    cmdTypes: {
        appCmds: appCmds,
        devCmds: devCmds,
        modeCmd: modeCmd,
        shmCmd: shmCmd
    },
    theDelay: 0,
    deviceId: '', //theHandler.event.context.System.device.deviceId,
    requestId: '', //theHandler.event.request.requestId,
    sessionId: '', //theHandler.event.session.sessionId,
    theCommand: theCommand
});

console.log(processData);

function cleanString(str) {
    return str.replace(/[^A-Za-z0-9 ]/gi, '').toLowerCase(); // Better regex... the other one was missing some things...
}

function getItems(theArrayToSearch, theArrayToCompare, theId, theLocation) {
    let theLocationItems = [...new Set(theArrayToSearch.map(theItems => theItems.theLocation))] // Here we grab all the possible locations in the array we are searching through.
    let theClosestLocation = Math.abs(theLocation - theLocationItems[0]); // Set the initial value to compare
    let theNewLocation = 0;

    for (let theLocationItem of theLocationItems) { // loop through all possible values and find the one with the smallest amount of spaces between the item in the arrayToSearch, and arrayToCompare.
        if (Math.abs(theLocation - theLocationItem) <= theClosestLocation) {
            theNewLocation = theLocationItem; // Set that smallest value to filter with
        }
    }
    return theArrayToSearch.filter((theAction) => theAction.theId === theId && theAction.theLocation === theNewLocation); // return the item based on theId and the smallest difference between the two array locations.
}