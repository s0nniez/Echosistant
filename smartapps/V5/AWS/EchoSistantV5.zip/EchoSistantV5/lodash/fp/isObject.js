var convert = require('./convert'),
    func = convert('isObject', require('../isObject'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
