var convert = require('./convert'),
    func = convert('flatten', require('../flatten'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
